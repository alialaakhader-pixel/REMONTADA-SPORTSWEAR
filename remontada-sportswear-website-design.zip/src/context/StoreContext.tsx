import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { PRODUCTS } from "../data/products";

export type CartItem = { id: string; size: string; color: string; qty: number };
export type Toast = { id: number; title: string; desc?: string };
export type Order = {
  id: string;
  date: string;
  total: number;
  status: "قيد التجهيز" | "تم الشحن" | "تم التوصيل";
  items: number;
};

type StoreContextValue = {
  cart: CartItem[];
  addToCart: (id: string, size: string, color: string, qty?: number) => void;
  removeFromCart: (id: string, size: string, color: string) => void;
  updateQty: (id: string, size: string, color: string, qty: number) => void;
  clearCart: () => void;
  count: number;
  subtotal: number;
  wishlist: string[];
  toggleWishlist: (id: string) => void;
  toasts: Toast[];
  pushToast: (title: string, desc?: string) => void;
  user: { name: string; email: string } | null;
  login: (name: string, email: string) => void;
  logout: () => void;
  orders: Order[];
  placeOrder: (total: number, items: number) => string;
};

const StoreContext = createContext<StoreContextValue | null>(null);

function load<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

export function StoreProvider({ children }: { children: ReactNode }) {
  const [cart, setCart] = useState<CartItem[]>(() => load("rt-cart", []));
  const [wishlist, setWishlist] = useState<string[]>(() => load("rt-wishlist", []));
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [user, setUser] = useState<{ name: string; email: string } | null>(() =>
    load("rt-user", null)
  );
  const [orders, setOrders] = useState<Order[]>(() =>
    load("rt-orders", [
      {
        id: "RT-2481",
        date: "قبل أسبوعين",
        total: 898,
        status: "تم التوصيل",
        items: 2,
      },
      {
        id: "RT-2624",
        date: "قبل 3 أيام",
        total: 124,
        status: "تم الشحن",
        items: 1,
      },
    ])
  );

  useEffect(() => localStorage.setItem("rt-cart", JSON.stringify(cart)), [cart]);
  useEffect(() => localStorage.setItem("rt-wishlist", JSON.stringify(wishlist)), [wishlist]);
  useEffect(() => localStorage.setItem("rt-user", JSON.stringify(user)), [user]);
  useEffect(() => localStorage.setItem("rt-orders", JSON.stringify(orders)), [orders]);

  const pushToast = useCallback((title: string, desc?: string) => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t, { id, title, desc }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3200);
  }, []);

  const addToCart = useCallback(
    (id: string, size: string, color: string, qty = 1) => {
      setCart((prev) => {
        const found = prev.find((i) => i.id === id && i.size === size && i.color === color);
        if (found) {
          return prev.map((i) =>
            i.id === id && i.size === size && i.color === color ? { ...i, qty: i.qty + qty } : i
          );
        }
        return [...prev, { id, size, color, qty }];
      });
      const p = PRODUCTS.find((x) => x.id === id);
      pushToast("تمت الإضافة إلى السلة", p ? `${p.name} • مقاس ${size}` : undefined);
    },
    [pushToast]
  );

  const removeFromCart = useCallback((id: string, size: string, color: string) => {
    setCart((prev) => prev.filter((i) => !(i.id === id && i.size === size && i.color === color)));
  }, []);

  const updateQty = useCallback((id: string, size: string, color: string, qty: number) => {
    setCart((prev) =>
      qty <= 0
        ? prev.filter((i) => !(i.id === id && i.size === size && i.color === color))
        : prev.map((i) =>
            i.id === id && i.size === size && i.color === color ? { ...i, qty } : i
          )
    );
  }, []);

  const clearCart = useCallback(() => setCart([]), []);

  const toggleWishlist = useCallback(
    (id: string) => {
      setWishlist((prev) => {
        const has = prev.includes(id);
        const p = PRODUCTS.find((x) => x.id === id);
        pushToast(has ? "أُزيل من المفضلة" : "أُضيف إلى المفضلة", p?.name);
        return has ? prev.filter((x) => x !== id) : [...prev, id];
      });
    },
    [pushToast]
  );

  const login = useCallback(
    (name: string, email: string) => {
      setUser({ name, email });
      pushToast("مرحباً بك في REMONTADA", `أهلاً ${name}`);
    },
    [pushToast]
  );

  const logout = useCallback(() => {
    setUser(null);
    pushToast("تم تسجيل الخروج", "إلى اللقاء مجدداً");
  }, [pushToast]);

  const placeOrder = useCallback(
    (total: number, items: number) => {
      const id = `RT-${Math.floor(1000 + Math.random() * 9000)}`;
      setOrders((prev) => [
        { id, date: "الآن", total, status: "قيد التجهيز", items },
        ...prev,
      ]);
      clearCart();
      pushToast("تم تأكيد الطلب", `رقم الطلب ${id}`);
      return id;
    },
    [clearCart, pushToast]
  );

  const { count, subtotal } = useMemo(() => {
    let c = 0;
    let s = 0;
    for (const i of cart) {
      const p = PRODUCTS.find((x) => x.id === i.id);
      if (!p) continue;
      c += i.qty;
      s += i.qty * p.price;
    }
    return { count: c, subtotal: s };
  }, [cart]);

  const value: StoreContextValue = {
    cart,
    addToCart,
    removeFromCart,
    updateQty,
    clearCart,
    count,
    subtotal,
    wishlist,
    toggleWishlist,
    toasts,
    pushToast,
    user,
    login,
    logout,
    orders,
    placeOrder,
  };

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore() {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error("useStore must be used within StoreProvider");
  return ctx;
}
