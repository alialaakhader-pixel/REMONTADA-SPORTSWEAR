import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { motion, useInView } from "framer-motion";
import {
  ArrowLeft,
  BadgePercent,
  Bike,
  Clock,
  Dumbbell,
  Flame,
  Footprints,
  Goal,
  Mountain,
  ShieldCheck,
  Sparkles,
  Target,
  Truck,
  Waves,
  Volleyball,
  Zap,
} from "lucide-react";
import { Reveal, SectionHead, Stars } from "../components/Reveal";
import { ProductCard } from "../components/ProductCard";
import { HERO_IMG, PRODUCTS, SPORTS_META } from "../data/products";

const fadeUp = {
  hidden: { opacity: 0, y: 44 },
  show: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.85, delay: 0.12 * i, ease: [0.22, 1, 0.36, 1] as const },
  }),
};

const TILES: { sport: keyof typeof SPORTS_META; icon: typeof Footprints }[] = [
  { sport: "running", icon: Footprints },
  { sport: "football", icon: Goal },
  { sport: "gym", icon: Dumbbell },
  { sport: "basketball", icon: Volleyball },
  { sport: "tennis", icon: Target },
  { sport: "swimming", icon: Waves },
  { sport: "cycling", icon: Bike },
  { sport: "trail", icon: Mountain },
];

const TIMELINE = [
  { value: 48000, suffix: "+", label: "عميل راضٍ" },
  { value: 12000, suffix: "+", label: "منتج مختلف" },
  { value: 98, suffix: "%", label: "تسليم في الوقت" },
  { value: 4.9, suffix: "/5", label: "متوسط التقييم" },
];

const TESTIMONIALS = [
  {
    name: "سعود الأحمد",
    role: "لاعب كرة قدم محترف",
    text: "لعبت بأقمصة REMONTADA كامل موسم 2025. الخامة قوية، التهوية ممتازة، واللون يعطي فريقنا مظهراً احترافياً.",
    rating: 5,
  },
  {
    name: "ليلى محمد",
    role: "عداءة ماراتون",
    text: "الحذاء الثاني الذي أستخدمه — يشعر طبيعياً مع الرجل طوال 21 كيلومتراً. الشحن وصل خلال يومين والسعر كان يستحق كل ريال.",
    rating: 5,
  },
  {
    name: "كريم حسن",
    role: "مدرب جيم",
    text: "مجموعة الجيم مظللة بشكل رائع. الجودة تليق باللاعبين الجادين، والمقاسات مناسبة للأجساد الكبيرة.",
    rating: 5,
  },
];

function CountUp({ value, suffix }: { value: number; suffix: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: "-40px" });
  const [n, setN] = useState(0);
  useEffect(() => {
    if (!inView) return;
    const start = performance.now();
    const dur = 1600;
    let raf = 0;
    const tick = (t: number) => {
      const p = Math.min(1, (t - start) / dur);
      const eased = 1 - Math.pow(1 - p, 3);
      setN(value * eased);
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [inView, value]);
  const display = value >= 100 ? Math.round(n).toLocaleString("en-US") : n.toFixed(1);
  return (
    <span ref={ref} className="font-display text-4xl font-black italic text-white md:text-5xl" dir="ltr">
      {display}
      <span className="text-fiery">{suffix}</span>
    </span>
  );
}

function Countdown() {
  const [left, setLeft] = useState("00:00:00");
  useEffect(() => {
    const t = setInterval(() => {
      const now = new Date();
      const end = new Date(now);
      end.setHours(23, 59, 59, 999);
      const d = Math.max(0, end.getTime() - now.getTime());
      const h = Math.floor(d / 3600000);
      const m = Math.floor(d / 60000) % 60;
      const s = Math.floor(d / 1000) % 60;
      const pad = (x: number) => String(x).padStart(2, "0");
      setLeft(`${pad(h)}:${pad(m)}:${pad(s)}`);
    }, 1000);
    return () => clearInterval(t);
  }, []);
  return <span dir="ltr" className="font-display text-3xl font-black tabular-nums text-white">{left}</span>;
}

export default function Home() {
  const popular = [...PRODUCTS].sort((a, b) => b.reviewCount - a.reviewCount).slice(0, 4);
  const latest = PRODUCTS.filter((p) => p.badge === "new").concat(
    PRODUCTS.filter((p) => p.badge !== "new" && p.badge !== "bestseller").slice(0, 2)
  ).slice(0, 4);

  return (
    <div className="overflow-hidden">
      {/* ══ HERO ══ */}
      <section className="grain relative flex min-h-[92vh] items-center overflow-hidden">
        <div className="absolute inset-0">
          <img src={HERO_IMG} alt="Rebel stadium" className="h-full w-full object-cover object-center" />
          <div className="absolute inset-0 bg-gradient-to-l from-ink via-ink/85 to-ink/45" />
          <div className="absolute inset-0 bg-gradient-to-t from-ink via-transparent to-ink/60" />
          <div className="speed-lines absolute inset-0" />
        </div>

        <div className="relative mx-auto grid w-full max-w-[1400px] grid-cols-1 items-center gap-12 px-4 py-24 md:px-8 lg:grid-cols-[1.15fr_0.85fr]">
          {/* Copy */}
          <motion.div initial="hidden" animate="show" className="max-w-2xl">
            <motion.div variants={fadeUp} custom={0} className="flex flex-wrap items-center gap-3">
              <span className="inline-flex items-center gap-2 rounded-full border border-fiery/40 bg-fiery/10 px-4 py-1.5 text-xs font-extrabold text-fiery">
                <Flame size={14} />
                العلامة الرياضية الفاخرة
              </span>
              <span className="inline-flex items-center gap-2 rounded-full border border-line bg-white/5 px-4 py-1.5 text-xs font-bold text-mist">
                <Sparkles size={13} className="text-gold" />
                هايبرثانية • هوية REMONTADA
              </span>
            </motion.div>

            <motion.h1
              variants={fadeUp}
              custom={1}
              className="mt-6 text-[3.2rem] font-black leading-[1.18] text-cream md:text-[4.6rem] md:leading-[1.12]"
            >
              ارتقِ إلى
              <span className="relative mx-2 inline-block text-fiery">
                مستواك
                <svg className="absolute -bottom-1 right-0 w-full" viewBox="0 0 200 12" fill="none" preserveAspectRatio="none">
                  <path d="M2 9C60 2.5 140 2.5 198 8.5" stroke="#ff1e1e" strokeWidth="4.5" strokeLinecap="round" opacity=".85" />
                </svg>
              </span>
              التالي
            </motion.h1>

            <motion.p variants={fadeUp} custom={2} className="mt-6 max-w-xl text-base leading-9 text-mist md:text-lg">
              ملابس وأحذية وإكسسوارات REMONTADA — صُممت للاعبين والمثابرين الذين لا يقبلون الاستسلام. كل تفصيل يخدم الأداء، كل منتج يخدم الانتصار.
            </motion.p>

            <motion.div variants={fadeUp} custom={3} className="mt-8 flex flex-wrap items-center gap-4">
              <Link
                to="/shop"
                className="group relative inline-flex items-center gap-3 overflow-hidden rounded-full bg-fiery px-8 py-4 text-base font-extrabold text-white shadow-[0_12px_45px_-8px_rgba(255,30,30,.6)] transition-all duration-300 hover:-translate-y-0.5 hover:bg-ember"
              >
                <span className="absolute inset-0 -translate-x-full bg-gradient-to-l from-transparent via-white/25 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
                تسوق الآن
                <ArrowLeft size={19} className="transition-transform duration-300 group-hover:-translate-x-1" />
              </Link>
              <Link
                to="/shop?filter=new"
                className="inline-flex items-center gap-3 rounded-full border border-white/20 bg-white/5 px-8 py-4 text-base font-extrabold text-cream backdrop-blur-md transition-all duration-300 hover:border-white/40 hover:bg-white/10"
              >
                اكتشف المجموعات الجديدة
              </Link>
            </motion.div>

            <motion.div variants={fadeUp} custom={4} className="mt-12 grid grid-cols-2 gap-6 sm:grid-cols-4">
              {TIMELINE.map((t) => (
                <div key={t.label} className="border-r-2 border-fiery/50 pr-4">
                  <CountUp value={t.value} suffix={t.suffix} />
                  <p className="mt-1 text-xs font-bold text-mist">{t.label}</p>
                </div>
              ))}
            </motion.div>
          </motion.div>

          {/* Emblem card */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 50 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ duration: 1.1, delay: 0.45, ease: [0.22, 1, 0.36, 1] }}
            className="relative mx-auto hidden w-full max-w-[400px] lg:block"
          >
            <div className="absolute -inset-12 rounded-full bg-neo/15 blur-[90px]" />
            <div className="animate-floaty relative overflow-hidden rounded-[2rem] border border-line bg-gradient-to-b from-smoke/80 to-coal p-6">
              <div className="absolute inset-0 opacity-40" style={{ background: "radial-gradient(circle at 50% 20%, rgba(58,180,255,.25), transparent 65%)" }} />
              <div className="relative flex flex-col items-center">
                <img
                  src="/images/ibex-emblem.png"
                  alt="REMONTADA ibex emblem"
                  className="mx-auto h-[290px] object-contain mix-blend-screen"
                />
                <p dir="ltr" className="mt-2 font-display text-4xl font-black italic tracking-tight text-white" style={{ textShadow: "0 0 30px rgba(58,180,255,.5)" }}>
                  REMONTADA
                </p>
                <p dir="ltr" className="mt-2 font-display text-[10px] font-bold tracking-[0.7em] text-neo/90">SPORTSWEAR</p>
              </div>
              <div className="absolute top-4 right-4 flex items-center gap-1.5 rounded-full border border-gold/30 bg-black/50 px-3 py-1.5 text-[11px] font-extrabold text-gold backdrop-blur">
                <Sparkles size={12} /> الإصدار الجديد
              </div>
              <div className="absolute bottom-4 left-4 flex items-center gap-2 rounded-xl border border-line bg-black/60 px-3 py-2 backdrop-blur">
                <span className="flex h-8 w-8 items-center justify-center rounded-full bg-fiery/20 text-fiery">
                  <Zap size={14} />
                </span>
                <div>
                  <p className="text-[11px] font-extrabold text-white">أفضل تصنيف</p>
                  <p className="text-[10px] font-bold text-mist">4.9/5 من 2,400+ تقييم</p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        <div className="relative pb-6">
          <div dir="ltr" className="overflow-hidden border-t border-line">
            <div className="flex w-max animate-marquee">
              {[0, 1].map((copy) => (
                <div key={copy} className="flex shrink-0 items-center" aria-hidden={copy === 1}>
                  {TILES.map((t, i) => (
                    <span key={i} className="flex items-center gap-3 px-10 py-4 text-mist">
                      <t.icon size={18} className="text-fiery" />
                      <span className="text-sm font-extrabold tracking-wide whitespace-nowrap">{SPORTS_META[t.sport].ar}</span>
                    </span>
                  ))}
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ══ FEATURED COLLECTIONS ══ */}
      <section className="mx-auto max-w-[1400px] px-4 py-20 md:px-8 md:py-28">
        <Reveal>
          <SectionHead
            eyebrow="المجموعات المميزة"
            title={<>اختر طريقك، فالانتصار يبدأ من <span className="text-fiery italic">تشكيلتك</span></>}
            sub="أربع مجموعات مصممة بعناية لتناسب طبيعة الرياضة وطبيعة المنافس."
          />
        </Reveal>

        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {(["running", "football", "gym", "trail"] as const).map((s, i) => {
            const meta = SPORTS_META[s];
            const Icon = TILES.find((t) => t.sport === s)!.icon;
            return (
              <Reveal key={s} delay={i * 0.08}>
                <Link
                  to={`/shop?sport=${s}`}
                  className="group relative block h-[360px] overflow-hidden rounded-3xl border border-line"
                >
                  <img
                    src={meta.img}
                    alt={meta.ar}
                    loading="lazy"
                    className="absolute inset-0 h-full w-full object-cover transition-transform duration-[1.4s] ease-out group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/30 to-transparent" />
                  <div className="absolute inset-x-0 bottom-0 flex items-end justify-between p-5">
                    <div>
                      <span className="mb-2 inline-flex h-10 w-10 items-center justify-center rounded-xl bg-white/10 text-white backdrop-blur">
                        <Icon size={18} />
                      </span>
                      <h3 className="text-2xl font-black text-white">{meta.ar}</h3>
                      <p className="mt-1 text-xs font-bold text-mist">اكتشفت القوة خلف كل مجموعة</p>
                    </div>
                    <span className="mb-1 flex h-12 w-12 items-center justify-center rounded-full bg-cream text-ink transition-all duration-300 group-hover:-translate-x-1.5 group-hover:bg-fiery group-hover:text-white">
                      <ArrowLeft size={18} />
                    </span>
                  </div>
                </Link>
              </Reveal>
            );
          })}
        </div>
      </section>

      {/* ══ POPULAR PRODUCTS ══ */}
      <section className="border-y border-line bg-coal/60 py-20 md:py-28">
        <div className="mx-auto max-w-[1400px] px-4 md:px-8">
          <Reveal className="flex flex-wrap items-end justify-between gap-6">
            <SectionHead
              align="start"
              eyebrow="الأكثر مبيعاً"
              title={<>الأكثر طلباً <span className="text-fiery">هذا الأسبوع</span></>}
              sub="أكثر منتجاتنا مبيعاً — أثبتت جودتها مع المتمرسين."
            />
            <Link to="/shop" className="group inline-flex items-center gap-2 rounded-full border border-line px-6 py-3 text-sm font-extrabold text-cream transition hover:border-fiery hover:text-white">
              عرض الكل
              <ArrowLeft size={16} className="transition-transform duration-300 group-hover:-translate-x-1" />
            </Link>
          </Reveal>
          <div className="mt-10 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {popular.map((p, i) => (
              <Reveal key={p.id} delay={i * 0.08}>
                <ProductCard product={p} />
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ══ WHY REMONTADA ══ */}
      <section className="mx-auto max-w-[1400px] px-4 py-20 md:px-8 md:py-28">
        <Reveal>
          <SectionHead
            eyebrow="لماذا REMONTADA؟"
            title={<>لا نبيع ملابس — <span className="text-fiery">نبني انتصاراً</span></>}
            sub="أربع ركائز تفصلنا عن المتاجر العادية."
          />
        </Reveal>
        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { icon: ShieldCheck, title: "ضمان أصلي 100%", desc: "كل منتج يحمل شهادة أصلية وضمان سنتان على جودة وقوة الخامة." },
            { icon: Truck, title: "توصيل سريع", desc: "شحن خلال 24-48 ساعة لجميع مدن المملكة مع تتبع لحظي." },
            { icon: Sparkles, title: "جودة فاخرة", desc: "خامة ماصّة للرطوبة، خياطة مزدوجة، ومتانة تفرض نفسها من أول لحظة." },
            { icon: BadgePercent, title: "أسعار تنافسية", desc: "أسعار عادلة بدون وسيط — لا وسائط ولا حديث — كل ريال يذهب إلى جودتك مباشرة." },
          ].map((f, i) => (
            <Reveal key={f.title} delay={i * 0.08}>
              <div className="group relative h-full overflow-hidden rounded-3xl border border-line bg-smoke p-7 transition-all duration-500 hover:-translate-y-2 hover:border-fiery/40">
                <div className="absolute -top-10 -end-10 h-32 w-32 rounded-full bg-fiery/10 blur-2xl transition-opacity duration-500 group-hover:opacity-100" />
                <span className="inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-fiery/12 text-fiery ring-1 ring-fiery/30">
                  <f.icon size={26} />
                </span>
                <h3 className="mt-5 text-lg font-black text-cream">{f.title}</h3>
                <p className="mt-2.5 text-[13px] leading-7 text-mist">{f.desc}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* ══ OFFER BANNER ══ */}
      <section className="relative overflow-hidden border-y border-line">
        <img
          src="https://images.pexels.com/photos/32471037/pexels-photo-32471037.jpeg?auto=compress&cs=tinysrgb&w=1600&q=75"
          alt="Sold out"
          loading="lazy"
          className="absolute inset-0 h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-l from-ink/95 via-ink/80 to-ink/40" />
        <div className="relative mx-auto flex max-w-[1400px] flex-col items-start justify-between gap-8 px-4 py-16 md:flex-row md:items-center md:px-8 md:py-20">
          <div className="max-w-xl">
            <span className="inline-flex items-center gap-2 rounded-full bg-gold/15 px-4 py-1.5 text-[11px] font-black tracking-wide text-gold ring-1 ring-gold/30">
              <Clock size={13} /> عرض الأسبوع — تنتهي في
            </span>
            <h2 className="mt-5 text-3xl font-black leading-snug text-white md:text-4xl">
              خصم <span className="text-fiery">30%</span> على العروض المميزة
            </h2>
            <p className="mt-3 text-sm leading-8 text-mist">
              اختر أي منتج من مجموعتنا المميزة واحصل على خصم موحد. الحد الأقصى للربع الحالي.
            </p>
          </div>
          <div className="flex flex-col items-center gap-4 md:items-end">
            <Countdown />
            <Link
              to="/shop?filter=sale"
              className="group inline-flex items-center gap-3 rounded-full bg-gold px-8 py-4 text-base font-black text-ink transition-all duration-300 hover:bg-white hover:shadow-[0_0_40px_rgba(201,169,106,.4)]"
            >
              سارع الآن
              <ArrowLeft size={18} className="transition-transform duration-300 group-hover:-translate-x-1" />
            </Link>
          </div>
        </div>
      </section>

      {/* ══ LATEST ARRIVALS ══ */}
      <section className="mx-auto max-w-[1400px] px-4 py-20 md:px-8 md:py-28">
        <Reveal className="flex flex-wrap items-end justify-between gap-6">
          <SectionHead
            align="start"
            eyebrow="أحدث الوصولات"
            title={<>ما لا يزال في <span className="text-neo">علوه جديد</span></>}
            sub="أحدث صيحة تقنية — تصميم مستوحى من المستقبل."
          />
        </Reveal>
        <div className="mt-10 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {latest.map((p, i) => (
            <Reveal key={p.id} delay={i * 0.08}>
              <ProductCard product={p} />
            </Reveal>
          ))}
        </div>
      </section>

      {/* ══ TESTIMONIALS ══ */}
      <section className="border-y border-line bg-coal/60 py-20 md:py-28">
        <div className="mx-auto max-w-[1400px] px-4 md:px-8">
          <Reveal>
            <SectionHead
              eyebrow="ثقة من أرض الملعب"
              title={<>ماذا يقول <span className="text-fiery">المتمرسون</span>؟</>}
            />
          </Reveal>
          <div className="mt-12 grid gap-5 md:grid-cols-3">
            {TESTIMONIALS.map((t, i) => (
              <Reveal key={t.name} delay={i * 0.1}>
                <figure className="relative h-full overflow-hidden rounded-3xl border border-line bg-smoke p-7">
                  <span className="absolute -top-3 -start-2 font-display text-[7rem] font-black leading-none text-white/5">
                    “
                  </span>
                  <Stars rating={t.rating} size={15} />
                  <blockquote className="relative mt-4 text-sm leading-8 text-cream/90">{t.text}</blockquote>
                  <figcaption className="mt-6 flex items-center gap-3">
                    <span className="flex h-11 w-11 items-center justify-center rounded-full bg-gradient-to-br from-fiery to-ember font-display text-sm font-black text-white">
                      {t.name[0]}
                    </span>
                    <div>
                      <p className="text-sm font-extrabold text-white">{t.name}</p>
                      <p className="text-[11px] font-bold text-mist">{t.role}</p>
                    </div>
                  </figcaption>
                </figure>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ══ CTA BAND ══ */}
      <section className="grain relative overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.pexels.com/photos/37927156/pexels-photo-37927156.jpeg?auto=compress&cs=tinysrgb&w=1700&q=75"
            alt="CTA"
            loading="lazy"
            className="h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-l from-ink via-ink/88 to-ink/45" />
        </div>
        <div className="relative mx-auto max-w-[1400px] px-4 py-24 md:px-8 md:py-32">
          <Reveal>
            <div className="max-w-2xl">
              <EyebrowCTA />
              <h2 className="mt-5 text-4xl font-black leading-[1.2] text-white md:text-6xl">
                تذكر أن كل انتصار
                <br />
                يبدأ بخطوة <span className="text-fiery">واحدة</span>.
              </h2>
              <p className="mt-5 max-w-lg text-base leading-8 text-mist">
                لا تنتظر اللحظة المناسبة — ابحث عن حدودك بأحذية وأقمصة REMONTADA.
              </p>
              <div className="mt-8 flex flex-wrap gap-4">
                <Link to="/shop" className="group inline-flex items-center gap-3 rounded-full bg-fiery px-8 py-4 font-extrabold text-white shadow-[0_12px_40px_-10px_rgba(255,30,30,.65)] transition hover:bg-ember">
                  ابدأ الآن
                  <ArrowLeft size={18} className="transition-transform group-hover:-translate-x-1" />
                </Link>
                <Link to="/about" className="inline-flex items-center gap-3 rounded-full border border-white/20 px-8 py-4 font-extrabold text-cream backdrop-blur transition hover:border-white/50">
                  قصة العلامة
                </Link>
              </div>
            </div>
          </Reveal>
        </div>
      </section>
    </div>
  );
}

function EyebrowCTA() {
  return (
    <span className="inline-flex items-center gap-2 text-[11px] font-extrabold tracking-[0.25em] text-gold">
      <span className="h-px w-8 bg-gold" /> REMONTADA — الإثارة مستمرة
    </span>
  );
}
