import { useEffect, useMemo, useRef, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import {
  ChevronDown,
  ChevronLeft,
  Heart,
  Link2,
  Minus,
  Plus,
  RotateCcw,
  ShieldCheck,
  ShoppingCart,
  Star,
  Truck,
  ZoomIn,
} from "lucide-react";
import { useStore } from "../context/StoreContext";
import { getProduct, relatedProducts, SPORTS_META } from "../data/products";
import { ProductCard } from "../components/ProductCard";
import { Stars } from "../components/Reveal";

type Review = { name: string; rating: number; comment: string; date: string };

const VIEWS = [
  { label: "أمامي", origin: "50% 42%" },
  { label: "علوي", origin: "50% 8%" },
  { label: "خلفي", origin: "50% 85%" },
];

function seedReviews(id: string): Review[] {
  const seeds = [
    { name: "أحمد النعيمي", rating: 5, comment: "الخامة فاخرة والخياطة محكمة — فعلاً فرق حقيقي عن غيره.", date: "قبل 3 أيام" },
    { name: "منى عبد الرحمن", rating: 5, comment: "السعر مقابل الجودة ممتاز. وصلني خلال يومين وبالضبط كالصورة.", date: "قبل أسبوع" },
    { name: "فهد العتيبي", rating: 4, comment: "جيد جداً، مقاس واحد أكبر من الطبيعي.", date: "قبل أسبوعين" },
  ];
  return seeds.slice(0, 2 + (id.length % 2));
}

export default function ProductPage() {
  const { id } = useParams();
  const product = getProduct(id ?? "");
  const [size, setSize] = useState<string>("");
  const [color, setColor] = useState<string>("");
  const [qty, setQty] = useState(1);
  const [viewIdx, setViewIdx] = useState(0);
  const [zoom, setZoom] = useState(false);
  const [origin, setOrigin] = useState("50% 42%");
  const [zoomOriginTouch, setZoomOriginTouch] = useState("50% 42%");
  const [openFaq, setOpenFaq] = useState<string | null>("desc");
  const [reviews, setReviews] = useState<Review[]>([]);
  const [rName, setRName] = useState("");
  const [rRating, setRRating] = useState(5);
  const [rComment, setRComment] = useState("");
  const [rErr, setRErr] = useState("");
  const [both, setBoth] = useState<string[]>([]);
  const imgRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();
  const { addToCart, wishlist, toggleWishlist, pushToast } = useStore();

  const related = useMemo(() => (product ? relatedProducts(product, 3) : []), [product]);
  const boughtTogether = useMemo(
    () => (product ? relatedProducts(product, 2).slice(0, 2) : []),
    [product]
  );

  useEffect(() => {
    if (product) {
      setSize(product.sizes[0]);
      setColor(product.colors[0].name);
      setQty(1);
      setReviews(seedReviews(product.id));
    }
  }, [product]);

  if (!product) {
    return (
      <div className="mx-auto flex max-w-2xl flex-col items-center px-4 py-32 text-center">
        <p className="text-6xl font-black text-white">404</p>
        <h1 className="mt-4 text-2xl font-black text-cream">المنتج غير موجود</h1>
        <p className="mt-3 text-sm text-mist">ربما حُذف من الفائض أو أنه لم يعد متوفراً.</p>
        <Link to="/shop" className="mt-8 rounded-full bg-fiery px-7 py-3.5 text-sm font-extrabold text-white transition hover:bg-ember">
          تصفح المتجر
        </Link>
      </div>
    );
  }

  const wished = wishlist.includes(product.id);
  const save = product.oldPrice ? Math.round((1 - product.price / product.oldPrice) * 100) : 0;

  const moveZoom = (clientX: number, clientY: number) => {
    const r = imgRef.current?.getBoundingClientRect();
    if (!r) return;
    const x = ((clientX - r.left) / r.width) * 100;
    const y = ((clientY - r.top) / r.height) * 100;
    setZoomOriginTouch(`${Math.min(95, Math.max(5, x))}% ${Math.min(95, Math.max(5, y))}%`);
  };

  const submitReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!rName.trim() || !rComment.trim()) return setRErr("يرجى تعبئة الاسم والمحتوى.");
    setReviews((prev) => [{ name: rName.trim(), rating: rRating, comment: rComment.trim(), date: "الآن" }, ...prev]);
    setRName(""); setRComment(""); setRRating(5); setRErr("");
    pushToast("شكراً لك!", "أُضيف تقييمك بنجاح");
  };

  const addBoughtTogether = () => {
    const chosen = boughtTogether.filter((p) => both.includes(p.id));
    if (chosen.length === 0) return pushToast("اختر منتجاً واحداً على الأقل");
    chosen.forEach((p) => addToCart(p.id, p.sizes[0], p.colors[0].name, 1));
  };

  const toggleBoth = (id: string) =>
    setBoth((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));

  return (
    <div className="mx-auto max-w-[1400px] px-4 py-10 md:px-8 md:py-14">
      <Link to="/shop" className="inline-flex items-center gap-1.5 text-xs font-bold text-mist transition hover:text-cream">
        <ChevronLeft size={14} /> العودة إلى المتجر
      </Link>

      <div className="mt-6 grid gap-10 lg:grid-cols-2 lg:gap-14">
        {/* Gallery */}
        <div>
          <div
            ref={imgRef}
            onMouseEnter={() => setZoom(true)}
            onMouseLeave={() => { setZoom(false); setOrigin("50% 42%"); }}
            onMouseMove={(e) => moveZoom(e.clientX, e.clientY)}
            className="group relative aspect-[4/5] cursor-crosshair overflow-hidden rounded-3xl border border-line bg-smoke"
          >
            <img
              src={product.image}
              alt={product.name}
              className="h-full w-full object-cover transition-transform duration-300 ease-out"
              style={{
                transformOrigin: zoom ? zoomOriginTouch : origin,
                transform: zoom ? "scale(2.1)" : "scale(1)",
              }}
            />
            <div className="pointer-events-none absolute bottom-4 start-4 flex items-center gap-2 rounded-full bg-black/60 px-3.5 py-2 text-[11px] font-extrabold text-cream backdrop-blur">
              <ZoomIn size={14} className="text-neo" /> مرّر للتكبير
            </div>
            {save > 0 && (
              <span className="absolute top-4 start-4 rounded-lg bg-fiery px-3 py-1.5 text-xs font-black text-white shadow-lg shadow-fiery/30">
                خصم {save}%
              </span>
            )}
          </div>
          <div className="mt-4 flex gap-3">
            {VIEWS.map((v, i) => (
              <button
                key={v.label}
                onClick={() => {
                  setViewIdx(i);
                  setOrigin(v.origin);
                  setZoomOriginTouch(v.origin);
                }}
                className={`relative h-20 w-16 overflow-hidden rounded-xl border transition ${
                  viewIdx === i ? "border-fiery ring-1 ring-fiery/50" : "border-line opacity-70 hover:opacity-100"
                }`}
              >
                <img src={product.image} alt={v.label} className="h-full w-full object-cover" style={{ objectPosition: v.origin }} />
              </button>
            ))}
            <div className="ms-auto flex items-center gap-2 text-[11px] font-bold text-mist">
              <span className="h-2 w-2 animate-pulse rounded-full bg-emerald-400" />
              متوفر — وصل قبل 24 ساعة
            </div>
          </div>
        </div>

        {/* Info */}
        <div>
          <div className="flex flex-wrap items-center gap-2 text-[11px] font-extrabold tracking-wide">
            <span className="rounded-full border border-line px-3 py-1 text-mist">{SPORTS_META[product.sport].ar}</span>
            <span className="rounded-full border border-line px-3 py-1 text-mist">{product.category}</span>
            <span className="rounded-full bg-neo/10 px-3 py-1 text-neo ring-1 ring-neo/30">{product.brand}</span>
          </div>
          <h1 className="mt-4 text-3xl font-black leading-tight text-white md:text-[2.6rem] md:leading-[1.2]">
            {product.name}
          </h1>
          <p className="mt-2 text-sm font-bold text-gold">{product.tagline}</p>

          <div className="mt-4 flex items-center gap-3">
            <Stars rating={product.rating} size={16} />
            <span className="text-sm font-extrabold text-white">{product.rating.toFixed(1)}</span>
            <span className="text-xs text-mist">({product.reviewCount + reviews.length} تقييم)</span>
          </div>

          <div className="mt-5 flex items-end gap-3">
            <span className="font-display text-4xl font-black italic text-white">{product.price}</span>
            <span className="pb-1.5 text-sm font-bold text-mist">ر.س</span>
            {product.oldPrice && (
              <>
                <span className="pb-2 text-lg font-semibold text-mist/70 line-through">{product.oldPrice} ر.س</span>
                <span className="mb-2 rounded-md bg-fiery/15 px-2 py-1 text-xs font-black text-fiery">وفّر {save}%</span>
              </>
            )}
          </div>

          <p className="mt-5 text-sm leading-8 text-mist">{product.desc}</p>

          {/* Colors */}
          <div className="mt-6">
            <p className="mb-2.5 text-xs font-extrabold tracking-wide text-cream">
              اللون: <span className="text-mist">{color}</span>
            </p>
            <div className="flex gap-2.5">
              {product.colors.map((c) => (
                <button
                  key={c.name}
                  onClick={() => setColor(c.name)}
                  aria-label={c.name}
                  className={`h-10 w-10 rounded-full border-2 transition active:scale-90 ${
                    color === c.name ? "border-fiery scale-110" : "border-transparent hover:scale-105"
                  }`}
                  style={{ background: c.hex }}
                />
              ))}
            </div>
          </div>

          {/* Sizes */}
          <div className="mt-5">
            <div className="mb-2.5 flex items-center justify-between">
              <p className="text-xs font-extrabold tracking-wide text-cream">
                المقاس: <span className="text-mist">{size}</span>
              </p>
              <button
                onClick={() => setOpenFaq("size")}
                className="text-[11px] font-bold text-neo underline-offset-4 hover:underline"
              >
                جدول المقاسات
              </button>
            </div>
            <div className="flex flex-wrap gap-2">
              {product.sizes.map((s) => (
                <button
                  key={s}
                  onClick={() => setSize(s)}
                  className={`h-11 min-w-12 rounded-xl border px-3 text-sm font-black transition active:scale-95 ${
                    size === s
                      ? "border-fiery bg-fiery text-white shadow-lg shadow-fiery/30"
                      : "border-line text-mist hover:border-white/30 hover:text-cream"
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          {/* qty + CTA */}
          <div className="mt-7 flex flex-wrap items-center gap-3">
            <div className="flex items-center rounded-xl border border-line bg-smoke">
              <button onClick={() => setQty((v) => Math.max(1, v - 1))} className="flex h-12 w-11 items-center justify-center text-mist transition hover:text-white" aria-label="إنقاص الكمية">
                <Minus size={16} />
              </button>
              <span className="w-10 text-center font-display text-lg font-black text-white" dir="ltr">{qty}</span>
              <button onClick={() => setQty((v) => Math.min(product.stock, v + 1))} className="flex h-12 w-11 items-center justify-center text-mist transition hover:text-white" aria-label="زيادة الكمية">
                <Plus size={16} />
              </button>
            </div>
            <button
              onClick={() => addToCart(product.id, size, color, qty)}
              className="flex h-12 flex-1 items-center justify-center gap-2.5 rounded-xl bg-fiery px-6 font-extrabold text-white shadow-[0_10px_35px_-8px_rgba(255,30,30,.6)] transition-all duration-300 hover:bg-ember active:scale-[0.98]"
            >
              <ShoppingCart size={18} /> أضف إلى السلة — {product.price * qty} ر.س
            </button>
            <button
              onClick={() => {
                addToCart(product.id, size, color, qty);
                navigate("/checkout");
              }}
              className="h-12 rounded-xl border border-white/20 px-6 font-extrabold text-cream transition hover:border-white/50 hover:bg-white/5"
            >
              اشترِ الآن
            </button>
            <button
              onClick={() => toggleWishlist(product.id)}
              aria-label="أضف إلى المفضلة"
              className={`flex h-12 w-12 items-center justify-center rounded-xl border transition active:scale-90 ${
                wished ? "border-fiery bg-fiery/15 text-fiery" : "border-line text-mist hover:border-white/30 hover:text-white"
              }`}
            >
              <Heart size={18} className={wished ? "fill-current" : ""} />
            </button>
            <button
              onClick={() => {
                navigator.clipboard?.writeText(window.location.href).catch(() => {});
                pushToast("تم نسخ الرابط", "شارك المنتج مع أصدقائك");
              }}
              aria-label="مشاركة"
              className="flex h-12 w-12 items-center justify-center rounded-xl border border-line text-mist transition hover:border-white/30 hover:text-white"
            >
              <Link2 size={18} />
            </button>
          </div>

          <div className="mt-5 grid grid-cols-3 gap-2">
            {[
              { icon: Truck, label: "توصيل 24-48 ساعة" },
              { icon: ShieldCheck, label: "ضمان أصلي 100%" },
              { icon: RotateCcw, label: "إرجاع خلال 14 يوماً" },
            ].map((t) => (
              <div key={t.label} className="flex flex-col items-center gap-1.5 rounded-xl border border-line bg-coal px-2 py-3 text-center">
                <t.icon size={17} className="text-neo" />
                <span className="text-[10px] font-extrabold text-mist leading-4">{t.label}</span>
              </div>
            ))}
          </div>

          {/* Accordion */}
          <div className="mt-6 divide-y divide-line rounded-2xl border border-line bg-coal">
            {[
              {
                key: "desc",
                title: "الوصف والخامة",
                body: (
                  <>
                    <p>{product.desc}</p>
                    <p className="mt-2">{product.spec}</p>
                  </>
                ),
              },
              {
                key: "size",
                title: "جدول المقاسات",
                body: (
                  <div className="space-y-1.5 text-[13px]">
                    {[
                      ["S", "90-94 سم"],
                      ["M", "95-99 سم"],
                      ["L", "100-105 سم"],
                      ["XL", "106-112 سم"],
                      ["XXL", "113-120 سم"],
                    ].map(([k, v]) => (
                      <div key={k} className="flex justify-between rounded-lg bg-white/4 px-3 py-2">
                        <span className="font-black text-cream">{k}</span>
                        <span className="text-mist">{v}</span>
                      </div>
                    ))}
                    <p className="pt-1 text-[11px] text-mist">ملاحظة: مقاسات الأحذية تتوافق مع المعدل العالمي — اختر مقاس بارتفاع نصف بوصة إذا كنت بين مقاسين.</p>
                  </div>
                ),
              },
              {
                key: "guarantee",
                title: "الضمان ورياضة العودة",
                body: <p>جميع منتجات REMONTADA ضمانت أصليّة لمدة سنتين. يمكن إرجاع أي سلعة خلال 14 يوماً من تاريخ الاستلام، بشرط أن تبقى بحالتها الأصلية.</p>,
              },
            ].map((a) => (
              <div key={a.key}>
                <button
                  onClick={() => setOpenFaq(openFaq === a.key ? null : a.key)}
                  className="flex w-full items-center justify-between p-4 text-start text-sm font-extrabold text-cream"
                >
                  {a.title}
                  <ChevronDown size={16} className={`text-mist transition-transform duration-300 ${openFaq === a.key ? "rotate-180 text-fiery" : ""}`} />
                </button>
                <AnimatePresence initial={false}>
                  {openFaq === a.key && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3 }}
                      className="overflow-hidden"
                    >
                      <div className="px-4 pb-4 text-[13px] leading-7 text-mist">{a.body}</div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Reviews */}
      <section className="mt-20">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="text-[11px] font-extrabold tracking-[0.2em] text-fiery">التقييمات</p>
            <h2 className="mt-2 text-2xl font-black text-white md:text-3xl">ماذا قال المتمرسون؟</h2>
          </div>
          <div className="flex items-center gap-2">
            <Stars rating={product.rating} size={18} />
            <span className="text-lg font-black text-white">{product.rating.toFixed(1)}</span>
            <span className="text-xs text-mist">({product.reviewCount + reviews.length})</span>
          </div>
        </div>

        <div className="mt-8 grid gap-6 lg:grid-cols-[1fr_360px]">
          <div className="space-y-4">
            {reviews.map((r, i) => (
              <div key={i} className="rounded-2xl border border-line bg-coal p-5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-ember to-fiery font-display text-sm font-black text-white">
                      {r.name[0]}
                    </span>
                    <div>
                      <p className="text-sm font-extrabold text-white">{r.name}</p>
                      <p className="text-[11px] text-mist">{r.date}</p>
                    </div>
                  </div>
                  <Stars rating={r.rating} size={13} />
                </div>
                <p className="mt-3 text-sm leading-7 text-mist">{r.comment}</p>
              </div>
            ))}
            <AnimatePresence>
              {reviews.length === 0 && (
                <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="rounded-2xl border border-line bg-coal p-6 text-center text-sm text-mist">
                  لا توجد تقييمات بعد — كن أول من يكتب تقييمه!
                </motion.p>
              )}
            </AnimatePresence>
          </div>

          <form onSubmit={submitReview} className="h-fit rounded-2xl border border-line bg-smoke p-5">
            <h3 className="text-base font-black text-white">أضف تقييمك</h3>
            <div className="mt-4 space-y-4">
              <div>
                <label className="mb-1.5 block text-xs font-bold text-mist">الاسم</label>
                <input value={rName} onChange={(e) => setRName(e.target.value)} className="field" placeholder="الاسم الكريم" />
              </div>
              <div>
                <label className="mb-1.5 block text-xs font-bold text-mist">التقييم</label>
                <div className="flex gap-1.5">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => setRRating(i)}
                      aria-label={`${i} نجوم`}
                      className="transition hover:scale-110"
                    >
                      <Star size={26} className={i <= rRating ? "fill-gold text-gold" : "fill-white/10 text-white/10"} />
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="mb-1.5 block text-xs font-bold text-mist">التعليق</label>
                <textarea value={rComment} onChange={(e) => setRComment(e.target.value)} rows={3} className="field resize-none" placeholder="كيف كان تصميمه مع الأداء؟" />
              </div>
              {rErr && <p className="text-xs font-bold text-fiery">{rErr}</p>}
              <button type="submit" className="w-full rounded-xl bg-cream py-3 text-sm font-extrabold text-ink transition hover:bg-white">
                نشر التقييم
              </button>
            </div>
          </form>
        </div>
      </section>

      {/* Bought together */}
      <section className="mt-16">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <p className="text-[11px] font-extrabold tracking-[0.2em] text-gold">اشترى معه أيضاً</p>
            <h2 className="mt-2 text-2xl font-black text-white">أكمل كل إطلالة</h2>
          </div>
        </div>
        <div className="mt-6 grid gap-4 sm:grid-cols-2">
          {boughtTogether.map((p) => (
            <button
              key={p.id}
              onClick={() => toggleBoth(p.id)}
              className={`flex items-center gap-4 rounded-2xl border p-4 text-start transition ${
                both.includes(p.id) ? "border-gold/60 bg-gold/10" : "border-line bg-coal hover:border-white/25"
              }`}
            >
              <img src={p.image} alt={p.name} className="h-20 w-20 rounded-xl object-cover" />
              <div className="flex-1">
                <p className="text-sm font-extrabold text-white">{p.name}</p>
                <p className="mt-0.5 text-xs font-bold text-mist">{p.category} • {p.brand}</p>
                <p className="mt-1 font-display text-lg font-black text-white">{p.price} ر.س</p>
              </div>
              <span
                className={`flex h-8 w-8 items-center justify-center rounded-full border-2 transition ${
                  both.includes(p.id) ? "border-gold bg-gold text-ink" : "border-line text-transparent"
                }`}
              >
                <Plus size={16} strokeWidth={3} />
              </span>
            </button>
          ))}
        </div>
        <button
          onClick={addBoughtTogether}
          className="mt-4 inline-flex items-center gap-2 rounded-full border border-gold/50 bg-gold/10 px-7 py-3 text-sm font-extrabold text-gold transition hover:bg-gold hover:text-ink"
        >
          <ShoppingCart size={16} /> أضف المجموعة إلى السلة
        </button>
      </section>

      {/* Related */}
      <section className="mt-16">
        <p className="text-[11px] font-extrabold tracking-[0.2em] text-fiery">منتجات مشابهة</p>
        <h2 className="mt-2 text-2xl font-black text-white">تستمر في استكشاف {product.category}</h2>
        <div className="mt-6 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {related.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>

      {/* mobile sticky bar */}
      <div className="fixed inset-x-0 bottom-0 z-[55] border-t border-line bg-coal/95 p-3 backdrop-blur-xl lg:hidden">
        <div className="flex items-center gap-3">
          <button
            onClick={() => addToCart(product.id, size, color, qty)}
            className="flex h-12 flex-1 items-center justify-center gap-2 rounded-xl bg-fiery font-extrabold text-white"
          >
            <ShoppingCart size={18} /> أضف إلى السلة
          </button>
          <span className="font-display text-lg font-black text-white">{product.price} ر.س</span>
        </div>
      </div>
      <div className="h-20 lg:hidden" />
    </div>
  );
}
