import { Link } from "react-router-dom";
import { ArrowLeft, Flame, Globe, Target, Trophy, Users } from "lucide-react";
import { Reveal, SectionHead } from "../components/Reveal";

const STORY = [
  {
    year: "عام 2022",
    title: "البداية من شغف",
    text: "بدأت REMONTADA في ورشة صغيرة كان حلمنا فيها «أن نحترم لحظة الاختبار». كانت مجموعة محدودة من الأحذية والملابس التي صمدت في أول اختبار للأداء والشكل.",
  },
  {
    year: "عام 2023",
    title: "الانتصار الأول",
    text: "أول شحناتنا وصلت خلال يومين، وتكوّنت لدينا قاعدة جماهيرية أولى. بدأت القصة تكبر تدريجاً بفضل الثقة والنشر الشفهي.",
  },
  {
    year: "عام 2026",
    title: "من العالم للعالم",
    text: "الاليوم REMONTADA نطمح أن نكون علامة رياضية وطنية ثم عالمية، للاعبين والمثابرين في كل مكان.",
  },
];

const VALUES = [
  { icon: Trophy, title: "الرؤية", text: "أن أكون علامة رياضية استثنائية تجعل كل متمرس يشعر وكأنه الأبطال على الملعب." },
  { icon: Target, title: "الرسالة", text: "أن نوفر ملابس ومعدات رياضية فاخرة بسعر عادل، وبخامة تتحمل أشد التمارين." },
  { icon: Flame, title: "لماذا الاسم؟", text: "REMONTADA بالإسبانية كلمة تعني «العودة» والانتصار. اخترناها لأننا نؤمن بأن كل مغلوب يعود قوياً، وكل لاعب يستحق عالياً." },
  { icon: Globe, title: "قيمنا", text: "الشفافية، الجودة المتفوقة، السرعة في الشحن، والثقة في كل منتج." },
];

const STATS = [
  { v: "+48 ألف", l: "عميل سعيد" },
  { v: "+12 ألف", l: "منتج مختلف" },
  { v: "24 ساعة", l: "زمن الشحن" },
  { v: "98%", l: "رضا العملاء" },
];

export default function About() {
  return (
    <div>
      {/* hero */}
      <section className="relative flex min-h-[70vh] items-end overflow-hidden">
        <img
          src="https://images.pexels.com/photos/37927156/pexels-photo-37927156.jpeg?auto=compress&cs=tinysrgb&w=1600&q=75"
          alt="Runner"
          className="absolute inset-0 h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/60 to-ink/40" />
        <div className="relative mx-auto w-full max-w-[1400px] px-4 pb-20 pt-40 md:px-8">
          <Reveal>
            <p className="text-[11px] font-extrabold tracking-[0.3em] text-fiery">من نحن</p>
            <h1 className="mt-4 max-w-3xl text-4xl font-black leading-[1.2] text-white md:text-6xl md:leading-[1.15]">
              قصة <span className="text-fiery">REMONTADA</span> تبدأ
              <br />
              من كل خطوة
            </h1>
            <p className="mt-5 max-w-xl text-base leading-8 text-mist">
              ثلاث سنوات من تشييد منتجات رياضية فاخرة صُممت للاعبين والمثابرين — في الرياض وفي العالم.
            </p>
          </Reveal>
        </div>
      </section>

      {/* story */}
      <section className="mx-auto max-w-[1400px] px-4 py-20 md:px-8 md:py-28">
        <Reveal>
          <SectionHead eyebrow="قصتنا" title={<>رحلتنا نحو <span className="text-fiery">الانتصار</span></>} />
        </Reveal>
        <div className="mt-14 grid gap-5 md:grid-cols-3">
          {STORY.map((s, i) => (
            <Reveal key={s.year} delay={i * 0.1}>
              <div className="group h-full rounded-3xl border border-line bg-coal p-7 transition-all duration-500 hover:-translate-y-1.5 hover:border-fiery/40">
                <p className="font-display text-5xl font-black italic text-white/10 transition group-hover:text-fiery/40">{i + 1}</p>
                <span className="mt-4 inline-block rounded-full border border-line bg-white/5 px-3 py-1 text-[11px] font-extrabold text-gold">{s.year}</span>
                <h3 className="mt-4 text-xl font-black text-white">{s.title}</h3>
                <p className="mt-2.5 text-sm leading-8 text-mist">{s.text}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* values */}
      <section className="border-y border-line bg-coal/50 py-20 md:py-28">
        <div className="mx-auto max-w-[1400px] px-4 md:px-8">
          <Reveal>
            <SectionHead eyebrow="الرؤية والرسالة" title={<>ماذا نمثل؟</>} sub="أربعة قمم حملتنا إلى هذا اليوم." />
          </Reveal>
          <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {VALUES.map((v, i) => (
              <Reveal key={v.title} delay={i * 0.08}>
                <div className="h-full rounded-3xl border border-line bg-smoke p-7 text-center">
                  <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-fiery/12 text-fiery ring-1 ring-fiery/30">
                    <v.icon size={26} />
                  </span>
                  <h3 className="mt-5 text-lg font-black text-white">{v.title}</h3>
                  <p className="mt-2 text-[13px] leading-7 text-mist">{v.text}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* numbers */}
      <section className="mx-auto max-w-[1400px] px-4 py-20 md:px-8">
        <div className="grid grid-cols-2 gap-5 lg:grid-cols-4">
          {STATS.map((s, i) => (
            <Reveal key={s.l} delay={i * 0.08}>
              <div className="rounded-3xl border border-line bg-gradient-to-b from-smoke to-coal p-7 text-center">
                <p dir="ltr" className="font-display text-3xl font-black italic text-white md:text-4xl">{s.v}</p>
                <p className="mt-2 text-xs font-bold tracking-wide text-mist">{s.l}</p>
              </div>
            </Reveal>
          ))}
        </div>

        <Reveal className="mt-16">
          <div className="flex flex-col items-center justify-between gap-6 rounded-3xl border border-line bg-gradient-to-l from-fiery/15 via-coal to-coal p-8 md:flex-row md:p-12">
            <div className="max-w-lg">
              <EyebrowDark />
              <h2 className="mt-4 text-2xl font-black leading-snug text-white md:text-3xl">
                جاهز لرفع مستوى مجموعتك التمرينية؟
              </h2>
            </div>
            <Link to="/shop" className="group inline-flex shrink-0 items-center gap-3 rounded-full bg-fiery px-8 py-4 font-extrabold text-white transition-all hover:bg-ember hover:shadow-[0_12px_40px_-10px_rgba(255,30,30,.6)]">
              ابدأ التسوق الآن
              <ArrowLeft size={18} className="transition-transform group-hover:-translate-x-1" />
            </Link>
          </div>
        </Reveal>
      </section>
    </div>
  );
}

function EyebrowDark() {
  return (
    <span className="inline-flex items-center gap-2 text-[11px] font-extrabold tracking-[0.25em] text-gold">
      <Users size={13} /> كن جزءاً من العائلة
    </span>
  );
}
