import { useState } from "react";
import { motion } from "framer-motion";
import { CircleCheck, Clock, Mail, MapPin, MessageCircle, Phone, Send } from "lucide-react";
import { Reveal, SectionHead } from "../components/Reveal";

export default function Contact() {
  const [sent, setSent] = useState(false);
  const [err, setErr] = useState("");
  const [form, setForm] = useState({ name: "", email: "", subject: "استفسار عام", message: "" });

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim() || !form.email.includes("@") || form.message.trim().length < 8) {
      return setErr("يرجى تعبئة الاسم والبريد الإلكتروني والرسالة (8 أحرف على الأقل).");
    }
    setErr("");
    setSent(true);
  };

  return (
    <div className="mx-auto max-w-[1300px] px-4 py-16 md:px-8 md:py-24">
      <Reveal>
        <SectionHead eyebrow="تواصل معنا" title={<>نبني <span className="text-fiery">الانتصار</span> معاً</>} sub="فريقنا جاهز للإجابة خلال ساعات — سؤالاً، اعتراضاً، أم نافذة هوية فقط." />
      </Reveal>

      <div className="mt-12 grid gap-6 lg:grid-cols-[1fr_1.2fr]">
        {/* info */}
        <div className="space-y-4">
          {[
            { icon: Phone, title: "الهاتف", value: "+966 55 000 0000", href: "tel:+966550000000", note: "متاح 9 صباحاً - 11 مساءً" },
            { icon: MessageCircle, title: "واتساب مباشر", value: "+966 55 000 0000", href: "https://wa.me/966550000000", note: "رد خلال 5 دقائق" },
            { icon: Mail, title: "البريد الإلكتروني", value: "hello@remontada.store", href: "mailto:hello@remontada.store", note: "بريد مموج ومجدّد" },
            { icon: Clock, title: "ساعات العمل", value: "السبت - الخميس", href: undefined, note: "9:00 - 22:00" },
          ].map((c, i) => (
            <Reveal key={c.title} delay={i * 0.07}>
              <a
                href={c.href}
                target={c.href?.startsWith("http") ? "_blank" : undefined}
                rel="noreferrer"
                className="group flex items-center gap-4 rounded-2xl border border-line bg-coal p-5 transition hover:border-fiery/40 hover:bg-smoke"
              >
                <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-fiery/12 text-fiery ring-1 ring-fiery/25">
                  <c.icon size={21} />
                </span>
                <div>
                  <p className="text-xs font-bold text-mist">{c.title}</p>
                  <p className="text-base font-black text-white group-hover:text-cream">{c.value}</p>
                  <p className="mt-0.5 text-[11px] font-bold text-mist">{c.note}</p>
                </div>
              </a>
            </Reveal>
          ))}

          {/* faux map */}
          <div className="relative mt-2 h-56 overflow-hidden rounded-2xl border border-line bg-[#0d1117]">
            <div className="absolute inset-0 opacity-60" style={{
              backgroundImage: "linear-gradient(rgba(255,255,255,.05) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.05) 1px, transparent 1px)",
              backgroundSize: "38px 38px",
            }} />
            <div className="absolute left-1/2 top-0 h-full w-14 -translate-x-1/2 bg-white/5" />
            <div className="absolute top-1/2 left-0 h-12 w-full -translate-y-1/2 bg-white/5" />
            <motion.span
              animate={{ scale: [1, 1.6, 1], opacity: [0.9, 0.3, 0.9] }}
              transition={{ repeat: Infinity, duration: 2.2, ease: "easeInOut" }}
              className="absolute left-1/2 top-1/2 h-9 w-9 -translate-x-1/2 -translate-y-1/2 rounded-full bg-fiery/30"
            />
            <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
              <MapPin size={38} className="fill-fiery text-fiery drop-shadow-[0_0_18px_rgba(255,30,30,.7)]" />
            </div>
            <div className="absolute bottom-3 start-3 rounded-xl bg-black/70 px-3.5 py-2 backdrop-blur">
              <p className="text-[11px] font-extrabold text-white">REMONTADA — الرياض، المملكة العربية السعودية</p>
              <p className="mt-0.5 text-[10px] font-bold text-mist">مركز العناية التوريد الذكي</p>
            </div>
          </div>
        </div>

        {/* form */}
        <Reveal delay={0.1}>
          <div className="rounded-3xl border border-line bg-coal p-6 md:p-8">
            <h2 className="text-xl font-black text-white">أرسل رسالة</h2>
            <p className="mt-1 text-xs text-mist">نرد خلال ساعات في أوقات العمل.</p>

            {sent ? (
              <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="mt-8 flex flex-col items-center py-6 text-center">
                <span className="flex h-16 w-16 items-center justify-center rounded-full bg-emerald-500/15 ring-1 ring-emerald-500/40">
                  <CircleCheck size={32} className="text-emerald-400" />
                </span>
                <h3 className="mt-5 text-lg font-black text-white">وصلك رسالتك، وتأكدنا</h3>
                <p className="mt-2 max-w-xs text-sm text-mist">فريقنا سيتواصل معك خلال 24 ساعة. شكراً لثقتك بـ REMONTADA.</p>
                <button onClick={() => { setSent(false); setForm({ name: "", email: "", subject: "استفسار عام", message: "" }); }} className="mt-6 rounded-full border border-line px-6 py-2.5 text-xs font-extrabold text-cream transition hover:border-white/40">
                  إرسال رسالة أخرى
                </button>
              </motion.div>
            ) : (
              <form onSubmit={submit} className="mt-6 space-y-4">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div>
                    <label className="field-label">الاسم الكامل</label>
                    <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="field" placeholder="مثال: أحمد الشمري" />
                  </div>
                  <div>
                    <label className="field-label">البريد الإلكتروني</label>
                    <input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="field" placeholder="you@email.com" dir="ltr" />
                  </div>
                </div>
                <div>
                  <label className="field-label">الموضوع</label>
                  <select value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} className="field appearance-none">
                    {["استفسار عام", "شحن وتسليم", "إرجاع أو استبدال", "شراكة أو نجمة", "أخرى"].map((s) => (
                      <option key={s} className="bg-coal">{s}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="field-label">رسالتك</label>
                  <textarea value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} rows={5} className="field resize-none" placeholder="اكتب سفيرك هنا..." />
                </div>
                {err && <p className="text-xs font-bold text-fiery">{err}</p>}
                <button type="submit" className="flex w-full items-center justify-center gap-2 rounded-2xl bg-fiery py-4 font-extrabold text-white transition hover:bg-ember">
                  <Send size={17} className="-scale-x-100" /> إرسال الرسالة
                </button>
              </form>
            )}
          </div>
        </Reveal>
      </div>
    </div>
  );
}
