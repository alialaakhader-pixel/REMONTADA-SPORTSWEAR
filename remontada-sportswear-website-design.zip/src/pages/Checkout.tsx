import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import {
  ArrowLeft,
  ArrowRight,
  Building2,
  Check,
  ChevronDown,
  CreditCard,
  MapPin,
  Package,
  ShieldCheck,
  Truck,
  Wallet,
} from "lucide-react";
import { useStore } from "../context/StoreContext";
import { CITIES, getProduct, shippingFee, TAX_RATE, type Product } from "../data/products";
import { SectionHead } from "../components/Reveal";

type Step = 1 | 2 | 3;

const METHODS = [
  { key: "card", icon: CreditCard, title: "بطاقة ائتمان", desc: "فيزا / ماستركارد / mada" },
  { key: "wallet", icon: Wallet, title: "المحافظ الإلكترونية", desc: "Apple Pay / STC Pay / مدى" },
  { key: "cash", icon: Package, title: "الدفع عند الاستلام", desc: "يدفع عند استلام الطلب" },
];

export default function Checkout() {
  const { cart, subtotal, placeOrder } = useStore();
  const [step, setStep] = useState<Step>(1);
  const [done, setDone] = useState(false);
  const [placedId, setPlacedId] = useState("");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [city, setCity] = useState("الرياض");
  const [address, setAddress] = useState("");
  const [method, setMethod] = useState("card");
  const [card, setCard] = useState({ number: "", name: "", expiry: "", cvv: "" });
  const [err, setErr] = useState("");

  const ship = shippingFee(city, subtotal);
  const tax = Math.round(subtotal * TAX_RATE);
  const total = subtotal + tax + ship;

  const details = useMemo(
    () =>
      cart
        .map((i) => ({ ...i, product: getProduct(i.id) }))
        .filter((x): x is { id: string; size: string; color: string; qty: number; product: Product } => !!x.product),
    [cart]
  );

  const validateStep1 = () => {
    if (!name.trim() || !phone.trim() || !address.trim()) return setErr("يرجى تعبئة الاسم ورقم الهاتف والعنوان.");
    if (!/^(05|9665|\+9665)\d{8}$/.test(phone.replace(/[\s-]/g, "")) && !/^\d{9,}$/.test(phone.replace(/[\s-]/g, "")))
      return setErr("رقم الهاتف غير صالح — أدخل رقماً صحيحاً.");
    setErr("");
    return true;
  };

  const validateStep2 = () => {
    if (method === "card") {
      const d = card.number.replace(/\s/g, "");
      if (d.length < 12 || !card.name.trim() || card.expiry.length < 4 || card.cvv.length < 3)
        return setErr("يرجى إدخال بيانات البطاقة بشكل صحيح.");
    }
    setErr("");
    return true;
  };

  const placeOrderFn = () => {
    if (details.length === 0) return;
    const items = cart.reduce((a, i) => a + i.qty, 0);
    const id = placeOrder(total, items);
    setPlacedId(id);
    setDone(true);
  };

  if (done) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-20 text-center">
        <motion.div initial={{ scale: 0.6, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ type: "spring", stiffness: 200, damping: 16 }}>
          <span className="mx-auto flex h-24 w-24 items-center justify-center rounded-full bg-emerald-500/15 ring-1 ring-emerald-500/40">
            <Check size={44} className="text-emerald-400" />
          </span>
        </motion.div>
        <h1 className="mt-8 text-3xl font-black text-white md:text-4xl">تم تأكيد طلبك بنجاح</h1>
        <p className="mt-3 text-mist">شكرًا لثقتك — فريق REMONTADA يستعد لتجهيز طلبك ويشحنه خلال 24 ساعة.</p>
        <div className="mx-auto mt-7 max-w-md rounded-2xl border border-line bg-coal p-5 text-right">
          <p className="text-[11px] font-extrabold tracking-wide text-mist">رقم الطلب</p>
          <p dir="ltr" className="mt-1 text-left font-display text-2xl font-black text-gold">{placedId || "RT-—"}</p>
          <div className="mt-4 grid grid-cols-2 gap-3 border-t border-line pt-4">
            <div><p className="text-[11px] text-mist">المدينة</p><p className="text-sm font-extrabold text-cream">{city}</p></div>
            <div><p className="text-[11px] text-mist">طريقة الدفع</p><p className="text-sm font-extrabold text-cream">{METHODS.find((m) => m.key === method)?.title}</p></div>
            <div><p className="text-[11px] text-mist">الإجمالي</p><p className="text-sm font-extrabold text-cream">{total.toLocaleString("en-US")} ر.س</p></div>
            <div><p className="text-[11px] text-mist">الشحن</p><p className="text-sm font-extrabold text-cream">24-48 ساعة</p></div>
          </div>
        </div>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <Link to="/shop" className="rounded-full bg-fiery px-7 py-3.5 text-sm font-extrabold text-white transition hover:bg-ember">
            متابعة التسوق
          </Link>
          <Link to="/account" className="rounded-full border border-line px-7 py-3.5 text-sm font-extrabold text-cream transition hover:border-white/40">
            طلباتي
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-[1400px] px-4 py-10 md:px-8 md:py-14">
      <SectionHead eyebrow="إتمام الطلب" title={<>لحظة <span className="text-fiery">الانتصار</span> مقربة</>} sub="ثلاث خطوات وحيدة — الاعتمادية الخاملة تنتهي هنا." />

      {/* steps */}
      <div className="mx-auto mt-10 flex max-w-3xl items-center gap-2">
        {[
          { n: 1, label: "معلومات الشحن", icon: MapPin },
          { n: 2, label: "طريقة الدفع", icon: CreditCard },
          { n: 3, label: "المراجعة", icon: Check },
        ].map((s, i) => (
          <div key={s.n} className="flex flex-1 items-center gap-2">
            <div
              className={`flex h-11 w-11 shrink-0 flex-col items-center justify-center rounded-full border-2 font-display text-sm font-black transition ${
                step > s.n
                  ? "border-emerald-500 bg-emerald-500/15 text-emerald-400"
                  : step === s.n
                  ? "border-fiery bg-fiery text-white shadow-[0_0_24px_rgba(255,30,30,.4)]"
                  : "border-line text-mist"
              }`}
            >
              {step > s.n ? <Check size={18} /> : s.n}
            </div>
            <div className="hidden text-xs font-extrabold text-mist sm:block">{s.label}</div>
            {i < 2 && <div className="mx-1 h-px flex-1 bg-line" />}
          </div>
        ))}
      </div>

      {/* empty cart guard */}
      {details.length === 0 ? (
        <div className="mt-14 text-center">
          <p className="text-lg font-black text-white">سلتك فارغة</p>
          <Link to="/shop" className="mt-5 inline-flex items-center gap-2 rounded-full bg-fiery px-7 py-3.5 text-sm font-extrabold text-white">
            تصفح المتجر <ArrowLeft size={15} />
          </Link>
        </div>
      ) : (
        <div className="mt-12 grid gap-8 lg:grid-cols-[1fr_380px]">
          <div>
            {err && (
              <div className="mb-5 flex items-center gap-2 rounded-xl border border-fiery/40 bg-fiery/10 px-4 py-3 text-sm font-bold text-red-400">
                <ShieldCheck size={16} /> {err}
              </div>
            )}

            {step === 1 && (
              <motion.form key="s1" initial={{ opacity: 0, x: -30 }} animate={{ opacity: 1, x: 0 }} className="rounded-3xl border border-line bg-coal p-6 md:p-8">
                <h2 className="text-xl font-black text-white">معلومات الشحن</h2>
                <p className="mt-1 text-xs text-mist">سنرسل طلبك إلى عنوانك بالضبط.</p>
                <div className="mt-6 grid gap-4 sm:grid-cols-2">
                  <div>
                    <label className="field-label">الاسم الكامل</label>
                    <input value={name} onChange={(e) => setName(e.target.value)} className="field" placeholder="مثال: عبدالله السالم" />
                  </div>
                  <div>
                    <label className="field-label">رقم الهاتف</label>
                    <input value={phone} onChange={(e) => setPhone(e.target.value)} className="field" placeholder="05XXXXXXXX" dir="ltr" />
                  </div>
                  <div>
                    <label className="field-label">المدينة</label>
                    <div className="relative">
                      <select value={city} onChange={(e) => setCity(e.target.value)} className="field appearance-none pe-10">
                        {CITIES.map((c) => (
                          <option key={c.name} value={c.name} className="bg-coal">{c.name}</option>
                        ))}
                      </select>
                      <ChevronDown size={16} className="pointer-events-none absolute end-3.5 top-1/2 -translate-y-1/2 text-mist" />
                    </div>
                  </div>
                  <div>
                    <label className="field-label">العنوان التفصيلي</label>
                    <input value={address} onChange={(e) => setAddress(e.target.value)} className="field" placeholder="الحي / الشارع / رقم المبنى" />
                  </div>
                </div>
                <button onClick={() => validateStep1() && setStep(2)} className="mt-7 flex w-full items-center justify-center gap-2 rounded-2xl bg-fiery py-4 font-extrabold text-white transition hover:bg-ember">
                  المتابعة إلى الدفع <ArrowLeft size={18} />
                </button>
              </motion.form>
            )}

            {step === 2 && (
              <motion.form key="s2" initial={{ opacity: 0, x: -30 }} animate={{ opacity: 1, x: 0 }} className="rounded-3xl border border-line bg-coal p-6 md:p-8">
                <h2 className="text-xl font-black text-white">طريقة الدفع</h2>
                <div className="mt-6 grid gap-3 sm:grid-cols-3">
                  {METHODS.map((m) => (
                    <button
                      key={m.key}
                      type="button"
                      onClick={() => setMethod(m.key)}
                      className={`rounded-2xl border p-4 text-center transition ${
                        method === m.key ? "border-fiery bg-fiery/10" : "border-line bg-smoke hover:border-white/25"
                      }`}
                    >
                      <m.icon size={22} className={`mx-auto ${method === m.key ? "text-fiery" : "text-mist"}`} />
                      <p className="mt-2 text-sm font-extrabold text-cream">{m.title}</p>
                      <p className="mt-1 text-[10px] font-bold text-mist">{m.desc}</p>
                    </button>
                  ))}
                </div>

                {method === "card" && (
                  <div className="mt-6 grid gap-4 sm:grid-cols-2">
                    <div className="sm:col-span-2">
                      <label className="field-label">رقم البطاقة</label>
                      <input
                        value={card.number}
                        onChange={(e) => setCard({ ...card, number: e.target.value })}
                        className="field font-display tracking-widest"
                        placeholder="0000 0000 0000 0000"
                        maxLength={19}
                        dir="ltr"
                        inputMode="numeric"
                      />
                    </div>
                    <div className="sm:col-span-2">
                      <label className="field-label">الاسم على البطاقة</label>
                      <input value={card.name} onChange={(e) => setCard({ ...card, name: e.target.value })} className="field" placeholder="Full name on card" dir="ltr" />
                    </div>
                    <div>
                      <label className="field-label">تاريخ الانتهاء</label>
                      <input value={card.expiry} onChange={(e) => setCard({ ...card, expiry: e.target.value })} className="field font-display" placeholder="MM/YY" maxLength={5} dir="ltr" />
                    </div>
                    <div>
                      <label className="field-label">رمز الأمان CVV</label>
                      <input value={card.cvv} onChange={(e) => setCard({ ...card, cvv: e.target.value })} className="field font-display" placeholder="123" maxLength={4} dir="ltr" inputMode="numeric" />
                    </div>
                  </div>
                )}
                {method === "wallet" && (
                  <div className="mt-6 flex items-center gap-3 rounded-2xl border border-line bg-smoke p-4">
                    <Building2 size={22} className="text-neo" />
                    <p className="text-xs leading-6 text-mist">ستُفعّل المحفظة بعد التأكيد — ستُرسَل رسالة بإتمام الدفع خلال لحظات.</p>
                  </div>
                )}
                {method === "cash" && (
                  <div className="mt-6 flex items-center gap-3 rounded-2xl border border-line bg-smoke p-4">
                    <Package size={22} className="text-gold" />
                    <p className="text-xs leading-6 text-mist">ادفع عند الاستلام نقداً أو ببطاقة مصرفية. تأكيد الطلب متاح خلال 30 دقيقة.</p>
                  </div>
                )}

                <div className="mt-7 flex gap-3">
                  <button type="button" onClick={() => setStep(1)} className="flex items-center gap-2 rounded-2xl border border-line px-6 py-4 font-extrabold text-mist transition hover:text-cream">
                    <ArrowRight size={17} /> رجوع
                  </button>
                  <button type="button" onClick={() => validateStep2() && setStep(3)} className="flex-1 rounded-2xl bg-fiery py-4 font-extrabold text-white transition hover:bg-ember">
                    المتابعة إلى المراجعة <ArrowLeft size={17} />
                  </button>
                </div>
              </motion.form>
            )}

            {step === 3 && (
              <motion.form key="s3" initial={{ opacity: 0, x: -30 }} animate={{ opacity: 1, x: 0 }} className="rounded-3xl border border-line bg-coal p-6 md:p-8">
                <h2 className="text-xl font-black text-white">مراجعة الطلب</h2>
                <div className="mt-5 space-y-3 text-sm">
                  {[
                    ["المستلم", name],
                    ["الهاتف", phone],
                    ["المدينة", city],
                    ["العنوان", address],
                    ["طريقة الدفع", METHODS.find((m) => m.key === method)?.title ?? ""],
                  ].map(([k, v]) => (
                    <div key={k} className="flex justify-between rounded-xl bg-white/4 px-4 py-3">
                      <span className="font-bold text-mist">{k}</span>
                      <span className="font-extrabold text-cream">{v}</span>
                    </div>
                  ))}
                </div>
                <div className="mt-5 flex gap-3">
                  <button type="button" onClick={() => setStep(2)} className="flex items-center gap-2 rounded-2xl border border-line px-6 py-4 font-extrabold text-mist transition hover:text-cream">
                    <ArrowRight size={17} /> تعديل
                  </button>
                  <button type="button" onClick={placeOrderFn} className="flex-1 rounded-2xl bg-fiery py-4 font-extrabold text-white shadow-[0_10px_35px_-8px_rgba(255,30,30,.6)] transition hover:bg-ember">
                    تأكيد الطلب — {total.toLocaleString("en-US")} ر.س
                  </button>
                </div>
                <p className="mt-4 flex items-center gap-2 text-[11px] font-bold text-mist">
                  <ShieldCheck size={14} className="text-emerald-400" /> دفع آمن ومشفر بمعايير الدفع العالمية
                </p>
              </motion.form>
            )}
          </div>

          {/* order summary */}
          <aside className="lg:sticky lg:top-24 lg:self-start">
            <div className="rounded-3xl border border-line bg-smoke p-6">
              <h3 className="text-base font-black text-white">ملخص الطلب</h3>
              <div className="mt-4 space-y-3">
                {details.map((i) => (
                  <div key={`${i.id}-${i.size}-${i.color}`} className="flex items-center gap-3">
                    <img src={i.product.image} alt={i.product.name} className="h-16 w-16 rounded-xl object-cover" />
                    <div className="flex-1">
                      <p className="text-xs font-extrabold text-cream">{i.product.name}</p>
                      <p className="mt-0.5 text-[11px] font-bold text-mist">مقاس {i.size} • لون {i.color} × {i.qty}</p>
                    </div>
                    <span className="font-display text-sm font-black text-white">{(i.product.price * i.qty).toLocaleString("en-US")}</span>
                  </div>
                ))}
              </div>
              <div className="mt-4 space-y-2.5 border-t border-line pt-4 text-sm">
                <div className="flex justify-between text-mist"><span>المجموع الفرعي</span><span className="font-bold text-cream">{subtotal.toLocaleString("en-US")} ر.س</span></div>
                <div className="flex justify-between text-mist"><span>الضريبة (15%)</span><span className="font-bold text-cream">{tax.toLocaleString("en-US")} ر.س</span></div>
                <div className="flex justify-between text-mist"><span>الشحن</span><span className="font-bold text-cream">{ship === 0 ? "مجاني" : `${ship} ر.س`}</span></div>
                <div className="flex items-end justify-between border-t border-line pt-3">
                  <span className="font-black text-white">الإجمالي</span>
                  <span className="font-display text-2xl font-black italic text-white">{total.toLocaleString("en-US")} <span className="text-xs not-italic text-mist">ر.س</span></span>
                </div>
              </div>
              <div className="mt-5 flex items-center gap-2 rounded-xl border border-line bg-coal p-3 text-[11px] font-bold text-mist">
                <Truck size={16} className="shrink-0 text-neo" /> توصيل سريع خلال 24-48 ساعة لجميع المناطق
              </div>
            </div>
          </aside>
        </div>
      )}
    </div>
  );
}
