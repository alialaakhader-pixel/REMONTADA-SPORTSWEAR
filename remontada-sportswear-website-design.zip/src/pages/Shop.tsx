import { useMemo, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import {
  ChevronDown,
  ChevronLeft,
  LayoutGrid,
  List,
  SlidersHorizontal,
  Star,
  Trash2,
  X,
} from "lucide-react";
import { ProductCard } from "../components/ProductCard";
import { Reveal, SectionHead } from "../components/Reveal";
import { PRODUCTS, SPORTS_META, CATEGORY_ORDER, GENDER_ORDER } from "../data/products";

const ALL_SIZES = Array.from(new Set(PRODUCTS.flatMap((p) => p.sizes)));

type SortKey = "default" | "newest" | "bestseller" | "price-asc" | "price-desc" | "rating";
const SORTS: { key: SortKey; label: string }[] = [
  { key: "default", label: "الترتيب الافتراضي" },
  { key: "newest", label: "الأحدث وصولاً" },
  { key: "bestseller", label: "الأكثر مبيعاً" },
  { key: "price-asc", label: "السعر: من الأقل" },
  { key: "price-desc", label: "السعر: من الأعلى" },
  { key: "rating", label: "الأعلى تقييماً" },
];

export default function Shop() {
  const [params] = useSearchParams();
  const [sport, setSport] = useState<string[]>(() => {
    const s = params.get("sport");
    return s ? [s] : [];
  });
  const [gender, setGender] = useState<string[]>([]);
  const [cat, setCat] = useState<string[]>([]);
  const [size, setSize] = useState<string[]>([]);
  const [maxPrice, setMaxPrice] = useState(900);
  const [minRating, setMinRating] = useState(0);
  const [sort, setSort] = useState<SortKey>("default");
  const [view, setView] = useState<"grid" | "list">("grid");
  const [mobileOpen, setMobileOpen] = useState(false);

  const q = params.get("q")?.trim().toLowerCase() ?? "";
  const filterNew = params.get("filter") === "new";
  const filterSale = params.get("filter") === "sale";

  const toggle = (arr: string[], v: string, set: (a: string[]) => void) =>
    set(arr.includes(v) ? arr.filter((x) => x !== v) : [...arr, v]);

  const reset = () => {
    setSport([]); setGender([]); setCat([]); setSize([]);
    setMaxPrice(900); setMinRating(0);
  };

  const filtered = useMemo(() => {
    let list = PRODUCTS.filter((p) => {
      if (q) {
        const hay = `${p.name} ${p.brand} ${p.category} ${SPORTS_META[p.sport].ar}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      if (sport.length && !sport.includes(p.sport)) return false;
      if (gender.length && !gender.includes(p.gender)) return false;
      if (cat.length && !cat.includes(p.category)) return false;
      if (size.length && !p.sizes.some((s) => size.includes(s))) return false;
      if (p.price > maxPrice) return false;
      if (p.rating < minRating) return false;
      if (filterNew && p.badge !== "new") return false;
      if (filterSale && p.badge !== "sale" && !p.oldPrice) return false;
      return true;
    });
    switch (sort) {
      case "price-asc": list = [...list].sort((a, b) => a.price - b.price); break;
      case "price-desc": list = [...list].sort((a, b) => b.price - a.price); break;
      case "rating": list = [...list].sort((a, b) => b.rating - a.rating); break;
      case "bestseller": list = [...list].sort((a, b) => b.reviewCount - a.reviewCount); break;
      case "newest": list = [...list].sort((a, b) => (b.badge === "new" ? 1 : 0) - (a.badge === "new" ? 1 : 0)); break;
    }
    return list;
  }, [q, sport, gender, cat, size, maxPrice, minRating, sort, filterNew, filterSale]);

  const activeCount =
    sport.length + gender.length + cat.length + size.length + (minRating ? 1 : 0) + (maxPrice < 900 ? 1 : 0) + (q ? 1 : 0);

  const Filters = ({ onClose }: { onClose?: () => void }) => (
    <div className="space-y-6">
      {(q || filterNew || filterSale) && (
        <div className="rounded-xl border border-gold/30 bg-gold/5 p-3 text-xs font-bold text-gold">
          بحث نشط{q ? `: «${q}»` : ""}{filterNew ? " • جديد" : ""}{filterSale ? " • عروض" : ""} — أنقر «مسح الكل» للإزالة
        </div>
      )}

      <div>
        <p className="mb-2.5 text-xs font-extrabold tracking-wide text-cream">الرياضة</p>
        <div className="grid grid-cols-2 gap-1.5">
          {Object.entries(SPORTS_META).map(([id, m]) => (
            <button
              key={id}
              onClick={() => toggle(sport, id, setSport)}
              className={`rounded-lg border px-2 py-2 text-[11px] font-bold transition ${
                sport.includes(id)
                  ? "border-fiery bg-fiery/15 text-white"
                  : "border-line text-mist hover:border-white/25 hover:text-cream"
              }`}
            >
              {m.ar}
            </button>
          ))}
        </div>
      </div>

      <div>
        <p className="mb-2.5 text-xs font-extrabold tracking-wide text-cream">الفئة</p>
        <div className="flex flex-wrap gap-1.5">
          {CATEGORY_ORDER.map((c) => (
            <button
              key={c}
              onClick={() => toggle(cat, c, setCat)}
              className={`rounded-full border px-3 py-1.5 text-[11px] font-bold transition ${
                cat.includes(c) ? "border-fiery bg-fiery/15 text-white" : "border-line text-mist hover:text-cream"
              }`}
            >
              {c}
            </button>
          ))}
        </div>
      </div>

      <div>
        <p className="mb-2.5 text-xs font-extrabold tracking-wide text-cream">النوع</p>
        <div className="flex flex-wrap gap-1.5">
          {GENDER_ORDER.map((g) => (
            <button
              key={g}
              onClick={() => toggle(gender, g, setGender)}
              className={`rounded-full border px-3 py-1.5 text-[11px] font-bold transition ${
                gender.includes(g) ? "border-fiery bg-fiery/15 text-white" : "border-line text-mist hover:text-cream"
              }`}
            >
              {g}
            </button>
          ))}
        </div>
      </div>

      <div>
        <p className="mb-2.5 text-xs font-extrabold tracking-wide text-cream">المقاس</p>
        <div className="flex flex-wrap gap-1.5">
          {ALL_SIZES.map((s) => (
            <button
              key={s}
              onClick={() => toggle(size, s, setSize)}
              className={`h-9 min-w-10 rounded-lg border px-2 text-[11px] font-black transition ${
                size.includes(s) ? "border-fiery bg-fiery text-white" : "border-line text-mist hover:text-cream"
              }`}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      <div>
        <div className="mb-2 flex items-center justify-between">
          <p className="text-xs font-extrabold tracking-wide text-cream">الحد الأقصى للسعر</p>
          <span className="rounded-md bg-white/5 px-2 py-0.5 font-display text-xs font-black text-white" dir="ltr">
            {maxPrice}
          </span>
        </div>
        <input
          type="range"
          min={100}
          max={900}
          step={10}
          value={maxPrice}
          onChange={(e) => setMaxPrice(Number(e.target.value))}
          className="w-full accent-fiery"
        />
      </div>

      <div>
        <p className="mb-2.5 text-xs font-extrabold tracking-wide text-cream">التقييم الأدنى</p>
        <div className="flex gap-1.5">
          {[0, 4.5, 4.8].map((r) => (
            <button
              key={r}
              onClick={() => setMinRating(r)}
              className={`flex flex-1 items-center justify-center gap-1 rounded-lg border py-2 text-[11px] font-bold transition ${
                minRating === r ? "border-fiery bg-fiery/15 text-white" : "border-line text-mist hover:text-cream"
              }`}
            >
              {r > 0 && <Star size={11} className="fill-gold text-gold" />}
              {r === 0 ? "الكل" : r.toFixed(1)}
            </button>
          ))}
        </div>
      </div>

      <button
        onClick={() => {
          reset();
          onClose?.();
        }}
        className="flex w-full items-center justify-center gap-2 rounded-xl border border-red-500/40 bg-red-500/10 py-3 text-sm font-extrabold text-red-400 transition hover:bg-red-500/20"
      >
        <Trash2 size={15} /> مسح جميع الفلاتر
      </button>
    </div>
  );

  return (
    <div className="mx-auto max-w-[1400px] px-4 py-10 md:px-8 md:py-14">
      <Reveal>
        <div className="flex items-center gap-2 text-xs font-bold text-mist">
          <Link to="/" className="transition hover:text-cream">الرئيسية</Link>
          <ChevronLeft size={13} />
          <span className="text-fiery">المتجر</span>
        </div>
      </Reveal>

      <Reveal delay={0.05}>
        <SectionHead
          align="start"
          eyebrow="المتجر"
          title={<>استكشف <span className="text-fiery">المجموعة</span> بأكملها</>}
          sub={q ? `نتائج البحث عن «${q}»` : "كل ما تحتاجه لكسب الانتصار — تصفح وتابع وحصل على ما يناسبك."}
        />
      </Reveal>

      {/* toolbar */}
      <Reveal delay={0.1}>
        <div className="mt-8 flex flex-wrap items-center justify-between gap-3 border-y border-line py-4">
          <button
            onClick={() => setMobileOpen(true)}
            className="inline-flex items-center gap-2 rounded-xl border border-line px-4 py-2.5 text-sm font-extrabold text-cream transition hover:border-fiery lg:hidden"
          >
            <SlidersHorizontal size={16} />
            فلاتر
            {activeCount > 0 && (
              <span className="flex h-5 w-5 items-center justify-center rounded-full bg-fiery text-[10px] font-black text-white">
                {activeCount}
              </span>
            )}
          </button>
          <p className="text-sm font-bold text-mist">
            {filtered.length > 0 ? (
              <>عرض <span className="text-white">{filtered.length}</span> منتج</>
            ) : (
              <span className="text-fiery">لا توجد نتائج مطابقة</span>
            )}
          </p>
          <div className="flex items-center gap-2.5">
            <div className="relative">
              <select
                value={sort}
                onChange={(e) => setSort(e.target.value as SortKey)}
                className="appearance-none rounded-xl border border-line bg-smoke py-2.5 pr-4 pl-10 text-xs font-extrabold text-cream outline-none transition focus:border-fiery/60"
              >
                {SORTS.map((s) => (
                  <option key={s.key} value={s.key} className="bg-coal">{s.label}</option>
                ))}
              </select>
              <ChevronDown size={15} className="pointer-events-none absolute end-3.5 top-1/2 -translate-y-1/2 text-mist" />
            </div>
            <div className="flex rounded-xl border border-line p-1">
              {(["grid", "list"] as const).map((v) => (
                <button
                  key={v}
                  onClick={() => setView(v)}
                  aria-label={v === "grid" ? "عرض الشبكة" : "عرض القائمة"}
                  className={`flex h-9 w-9 items-center justify-center rounded-lg transition ${view === v ? "bg-fiery text-white" : "text-mist hover:text-cream"}`}
                >
                  {v === "grid" ? <LayoutGrid size={16} /> : <List size={16} />}
                </button>
              ))}
            </div>
          </div>
        </div>
      </Reveal>

      <div className="mt-8 grid gap-8 lg:grid-cols-[260px_1fr]">
        {/* desktop sidebar */}
        <aside className="hidden lg:block">
          <div className="sticky top-24 max-h-[calc(100vh-7rem)] overflow-y-auto rounded-2xl border border-line bg-coal p-5">
            <Filters />
          </div>
        </aside>

        {/* grid */}
        {filtered.length === 0 ? (
          <div className="col-span-2 flex flex-col items-center justify-center rounded-3xl border border-dashed border-line py-28 text-center">
            <p className="text-lg font-black text-cream">لا توجد منتجات مطابقة لأهدافك</p>
            <p className="mt-2 max-w-sm text-sm text-mist">جرّب تعديل الفلاتر أو إزالة المرشحات واستمتع بالمزيد.</p>
            <button onClick={reset} className="mt-5 rounded-full bg-fiery px-7 py-3 text-sm font-extrabold text-white transition hover:bg-ember">
              مسح الفلاتر
            </button>
          </div>
        ) : view === "grid" ? (
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 xl:grid-cols-3">
            {filtered.map((p, i) => (
              <Reveal key={p.id} delay={Math.min(i * 0.06, 0.4)}>
                <ProductCard product={p} />
              </Reveal>
            ))}
          </div>
        ) : (
          <div className="flex flex-col gap-4">
            {filtered.map((p, i) => (
              <Reveal key={p.id} delay={Math.min(i * 0.05, 0.35)}>
                <Link
                  to={`/product/${p.id}`}
                  className="group flex flex-col gap-4 rounded-2xl border border-line bg-coal p-4 transition hover:border-fiery/40 sm:flex-row sm:items-center"
                >
                  <img src={p.image} alt={p.name} className="h-44 w-full rounded-xl object-cover sm:h-28 sm:w-36" />
                  <div className="flex-1">
                    <p className="text-[11px] font-bold text-mist">{p.category} • {SPORTS_META[p.sport].ar} • {p.brand}</p>
                    <h3 className="mt-1 text-xl font-black text-white group-hover:text-cream">{p.name}</h3>
                    <p className="mt-1 text-xs font-semibold text-mist">{p.tagline}</p>
                    <div className="mt-2 flex items-center gap-2">
                      <Star size={13} className="fill-gold text-gold" />
                      <span className="text-xs font-bold text-cream">{p.rating.toFixed(1)}</span>
                      <span className="text-xs text-mist">({p.reviewCount} تقييم)</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between gap-3 sm:flex-col sm:items-end sm:justify-center">
                    <div className="text-end">
                      {p.oldPrice && <p className="text-xs font-semibold text-mist/70 line-through">{p.oldPrice} ر.س</p>}
                      <p className="font-display text-2xl font-black text-white">
                        {p.price} <span className="text-xs font-bold text-mist">ر.س</span>
                      </p>
                    </div>
                    <span className="rounded-full bg-fiery px-5 py-2.5 text-xs font-extrabold text-white transition group-hover:bg-ember">
                      عرض المنتج
                    </span>
                  </div>
                </Link>
              </Reveal>
            ))}
          </div>
        )}
      </div>

      {/* mobile filter drawer */}
      <AnimatePresence>
        {mobileOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setMobileOpen(false)}
              className="fixed inset-0 z-[70] bg-ink/70 backdrop-blur-sm lg:hidden"
            />
            <motion.div
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", stiffness: 320, damping: 34 }}
              className="fixed inset-x-0 bottom-0 z-[75] max-h-[85vh] overflow-y-auto rounded-t-3xl border-t border-line bg-coal p-5 lg:hidden"
            >
              <div className="mx-auto mb-4 h-1 w-12 rounded-full bg-line" />
              <div className="mb-5 flex items-center justify-between">
                <h3 className="text-lg font-black text-white">الفلاتر</h3>
                <button onClick={() => setMobileOpen(false)} className="flex h-10 w-10 items-center justify-center rounded-full border border-line text-mist">
                  <X size={18} />
                </button>
              </div>
              <Filters onClose={() => setMobileOpen(false)} />
              <button
                onClick={() => setMobileOpen(false)}
                className="mt-6 w-full rounded-xl bg-fiery py-4 text-sm font-extrabold text-white"
              >
                عرض {filtered.length} منتج
              </button>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
