import { ArrowLeft, RotateCcw, ShieldCheck, Truck, Undo2 } from "lucide-react";
import { Link } from "react-router-dom";
import { SectionHead, Reveal } from "../components/Reveal";

const SECTIONS = [
  {
    icon: Undo2,
    title: "الإرجاع والاستبدال",
    body: [
      "يمكنك إرجاع أي منتج خلال 14 يوماً من تاريخ الاستلام، بشرط أن يبقى بحالته الأصلية مع علبته وملصقه.",
      "تقدر اختيار الاستبدال بمنتج آخر من نفس المجموعة، أو استرداد المبالغ الكلية عبر نفس طريقة الدفع الأصلية.",
      "تكاليف الإرجاع: الشحن المجاني للعميل إذا وصل المنتج معطلاً أو مختلاً، و35 ر.س فقط للإرجاع المهني.",
    ],
  },
  {
    icon: Truck,
    title: "الشحن والتوصيل",
    body: [
      "نحصل على توصيل سريع خلال 24-48 ساعة في المدن الرئيسية، و48-72 ساعة في المدن الأخرى.",
      "شحن مجاني 100% للطلبات التي تتجاوز 300 ر.س.",
      "تتبع لحظي لطلبك عبر رسالة نصية وبريد إلكتروني أثناء كل مرحلة.",
    ],
  },
  {
    icon: ShieldCheck,
    title: "ضمان الجودة",
    body: [
      "نمنح كل منتج ضمان أصلية لمدة سنتين من تاريخ الاستلام.",
      "إذا لم يُعالج الضمان، تُسترد المبالغ المدفوعة كاملاً خلال 7 أيام عمل.",
      "هذه السياسة لا تشمل التصرف أو الاستهلاك الشخصي للمنتج.",
    ],
  },
  {
    icon: RotateCcw,
    title: "استبدال الكاسد والمُختلط",
    body: [
      "عند استلام المنتج بشكل غير صحيح: نرسل لك منتجاً آخر فوراً أو نسترد المبلغ كاملاً خلال 48 ساعة.",
      "عند تعطل خاصية عن الأداء الاعتيادي، يُطبق الضمان خلال 14 يوماً.",
    ],
  },
];

export default function Refund() {
  return (
    <div className="mx-auto max-w-4xl px-4 py-16 md:px-8 md:py-24">
      <Reveal>
        <SectionHead eyebrow="المرجعية القانونية" title={<>سياسة <span className="text-fiery">الإرجاع والاستبدال والشحن</span></>} sub="سياسة واضحة تجعلك مطمئناً قبل الشراء." />
      </Reveal>

      <div className="mt-12 space-y-5">
        {SECTIONS.map((s, i) => (
          <Reveal key={s.title} delay={i * 0.08}>
            <div className="rounded-3xl border border-line bg-coal p-6 md:p-8">
              <div className="flex items-center gap-4">
                <span className="flex h-[52px] w-[52px] shrink-0 items-center justify-center rounded-2xl bg-fiery/12 text-fiery ring-1 ring-fiery/30">
                  <s.icon size={24} />
                </span>
                <h2 className="text-xl font-black text-white">{s.title}</h2>
              </div>
              <ul className="mt-4 space-y-3 ps-2">
                {s.body.map((b, j) => (
                  <li key={j} className="flex gap-3 text-sm leading-8 text-mist">
                    <span className="mt-3 h-1.5 w-1.5 shrink-0 rounded-full bg-fiery" />
                    {b}
                  </li>
                ))}
              </ul>
            </div>
          </Reveal>
        ))}
      </div>

      <Reveal>
        <div className="mt-10 flex flex-col items-center justify-between gap-4 rounded-3xl border border-line bg-gradient-to-l from-smoke to-coal p-7 md:flex-row">
          <p className="text-sm text-mist">لديك سؤال عن السياسة؟ تواصل معنا مباشرة.</p>
          <Link to="/contact" className="group inline-flex items-center gap-2 rounded-full bg-fiery px-6 py-3 text-sm font-extrabold text-white transition hover:bg-ember">
            التواصل معنا
            <ArrowLeft size={15} className="transition-transform group-hover:-translate-x-1" />
          </Link>
        </div>
      </Reveal>

      <p className="mt-8 text-center text-[11px] text-mist/60">آخر تحديث للسياسة: يناير 2026 — REMONTADA SPORTSWEAR</p>
    </div>
  );
}
