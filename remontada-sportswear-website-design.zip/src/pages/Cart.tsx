import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowLeft, ChevronDown, Minus, Plus, ShieldCheck, ShoppingCart, Trash2 } from "lucide-react";
import { useStore } from "../context/StoreContext";
import { CITIES, getProduct, shippingFee, TAX_RATE } from "../data/products";
import { SectionHead } from "../components/Reveal";

export default function Cart() {
  const { cart, removeFromCart, updateQty, subtotal, pushToast } = useStore();
  const [city, setCity] = useState("الرياض");
  const [promo, setPromo] = useState("");
  const [applied, setApplied] = useState<string | null>(null);

  const taxable = useMemo(() => subtotal - (applied ? Math.round(subtotal * 0.3) : 0), [subtotal, applied]);
  const tax = Math.round(taxable * TAX_RATE);
  const ship = shippingFee(city, subtotal);
  const discount = applied ? Math.round(subtotal * 0.3) : 0;
  const total = taxable + tax + ship;

  const applyPromo = () => {
    if (promo.trim().toUpperCase() === "REMONTADA30") {
      setApplied("REMONTADA30");
      pushToast("تم تفعيل الكوبون", "خصم 30% يطبّق تلقائياً");
    } else {
      pushToast("كوبون غير صالح", "جرّب REMONTADA30");
    }
  };

  return (
    <div className="mx-auto max-w-[1400px] px-4 py-10 md:px-8 md:py-14">
      <SectionHead
        align="start"
        eyebrow="سلتي"
        title={<>سلة التسوق <span className="text-fiery">({cart.length} {cart.length > 1 ? "قطع" : "قطعة"})</span></>}
        sub="راجع طلباتك، اضبط المقاسات، وأكمل الشحن بلمسة زر واحدة."
      />

      {cart.length === 0 ? (
        <div className="mt-10 flex flex-col items-center justify-center rounded-3xl border border-dashed border-line py-24 text-center">
          <span className="flex h-20 w-20 items-center justify-center rounded-3xl bg-smoke">
            <ShoppingCart size={34} className="text-mist" />
          </span>
          <h2 className="mt-6 text-2xl font-black text-white">سلتك فارغة حالياً</h2>
          <p className="mt-2 max-w-sm text-sm text-mist">لا يوجد ما يقلق — استعرض المتجر وابنِ فريقك في دقائق.</p>
          <Link to="/shop" className="mt-7 inline-flex items-center gap-2 rounded-full bg-fiery px-7 py-3.5 text-sm font-extrabold text-white transition hover:bg-ember">
            تصفح المتجر <ArrowLeft size={16} />
          </Link>
        </div>
      ) : (
        <div className="mt-10 grid gap-8 lg:grid-cols-[1fr_380px]">
          {/* items */}
          <div className="space-y-4">
            <AnimatePresence initial={false}>
              {cart.map((item) => {
                const p = getProduct(item.id);
                if (!p) return null;
                return (
                  <motion.div
                    key={`${item.id}-${item.size}-${item.color}`}
                    layout
                    initial={{ opacity: 0, y: 16 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, x: -60, height: 0, marginBottom: 0 }}
                    className="flex flex-col gap-4 rounded-2xl border border-line bg-coal p-4 sm:flex-row"
                  >
                    <Link to={`/product/${p.id}`} className="shrink-0">
                      <img src={p.image} alt={p.name} className="aspect-square h-28 w-28 rounded-xl object-cover" />
                    </Link>
                    <div className="flex-1">
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <Link to={`/product/${p.id}`} className="text-base font-black text-white transition hover:text-fiery">
                            {p.name}
                          </Link>
                          <div className="mt-1.5 flex flex-wrap items-center gap-2 text-[11px] font-bold text-mist">
                            <span className="rounded-md bg-white/5 px-2 py-1">مقاس: {item.size}</span>
                            <span className="flex items-center gap-1.5 rounded-md bg-white/5 px-2 py-1">
                              <span className="h-3 w-3 rounded-full border border-white/20" style={{ background: p.colors.find((c) => c.name === item.color)?.hex }} />
                              {item.color}
                            </span>
                          </div>
                        </div>
                        <button
                          onClick={() => removeFromCart(item.id, item.size, item.color)}
                          aria-label="حذف"
                          className="flex h-9 w-9 items-center justify-center rounded-lg border border-line text-mist transition hover:border-red-500/50 hover:bg-red-500/10 hover:text-red-400"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                      <div className="mt-4 flex items-center justify-between">
                        <div className="flex items-center rounded-xl border border-line bg-smoke">
                          <button onClick={() => updateQty(item.id, item.size, item.color, item.qty - 1)} className="flex h-10 w-10 items-center justify-center text-mist transition hover:text-white" aria-label="تقليل">
                            <Minus size={15} />
                          </button>
                          <span className="w-10 text-center font-display text-base font-black text-white" dir="ltr">{item.qty}</span>
                          <button onClick={() => updateQty(item.id, item.size, item.color, item.qty + 1)} className="flex h-10 w-10 items-center justify-center text-mist transition hover:text-white" aria-label="زيادة">
                            <Plus size={15} />
                          </button>
                        </div>
                        <p className="font-display text-xl font-black text-white">
                          {(p.price * item.qty).toLocaleString("en-US")} <span className="text-xs text-mist">ر.س</span>
                        </p>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>

          {/* summary */}
          <aside className="lg:sticky lg:top-24 lg:self-start">
            <div className="rounded-3xl border border-line bg-smoke p-6">
              <h3 className="text-lg font-black text-white">ملخص الطلب</h3>

              {/* shipping city */}
              <div className="mt-5">
                <label className="mb-1.5 block text-xs font-bold text-mist">المدينة</label>
                <div className="relative">
                  <select value={city} onChange={(e) => setCity(e.target.value)} className="field appearance-none pe-10">
                    {CITIES.map((c) => (
                      <option key={c.name} value={c.name} className="bg-coal">{c.name}</option>
                    ))}
                  </select>
                  <ChevronDown size={16} className="pointer-events-none absolute end-3.5 top-1/2 -translate-y-1/2 text-mist" />
                </div>
                <p className="mt-2 text-[11px] font-bold text-mist">
                  {ship === 0 ? "شحن مجاني — مبروك!" : `رسوم الشحن: ${ship} ر.س`}
                </p>
              </div>

              {/* promo */}
              <div className="mt-5">
                <label className="mb-1.5 block text-xs font-bold text-mist">كوبون الخصم</label>
                {applied ? (
                  <div className="flex items-center justify-between rounded-xl border border-emerald-500/30 bg-emerald-500/10 px-3.5 py-3">
                    <span className="text-xs font-extrabold text-emerald-400">REMONTADA30 مفعّل</span>
                    <button onClick={() => setApplied(null)} className="text-[11px] font-bold text-mist underline">إزالة</button>
                  </div>
                ) : (
                  <div className="flex gap-2">
                    <input value={promo} onChange={(e) => setPromo(e.target.value)} className="field" placeholder="REMONTADA30" dir="ltr" />
                    <button onClick={applyPromo} className="shrink-0 rounded-xl border border-fiery/50 bg-fiery/10 px-4 text-xs font-extrabold text-fiery transition hover:bg-fiery hover:text-white">
                      تطبيق
                    </button>
                  </div>
                )}
              </div>

              <div className="mt-5 space-y-2.5 border-t border-line pt-5 text-sm">
                <div className="flex justify-between text-mist"><span>المجموع الفرعي</span><span className="font-bold text-cream">{subtotal.toLocaleString("en-US")} ر.س</span></div>
                {discount > 0 && (
                  <div className="flex justify-between text-emerald-400"><span>الخصم (30%)</span><span className="font-bold">-{discount.toLocaleString("en-US")} ر.س</span></div>
                )}
                <div className="flex justify-between text-mist"><span>الضريبة (15%)</span><span className="font-bold text-cream">{tax.toLocaleString("en-US")} ر.س</span></div>
                <div className="flex justify-between text-mist"><span>الشحن</span><span className="font-bold text-cream">{ship === 0 ? "مجاني" : `${ship} ر.س`}</span></div>
                <div className="flex items-end justify-between border-t border-line pt-4">
                  <span className="text-base font-black text-white">الإجمالي</span>
                  <span className="font-display text-3xl font-black italic text-white">{total.toLocaleString("en-US")} <span className="text-sm not-italic text-mist">ر.س</span></span>
                </div>
              </div>

              <Link
                to="/checkout"
                className="mt-6 flex items-center justify-center gap-2.5 rounded-2xl bg-fiery py-4 font-extrabold text-white shadow-[0_10px_35px_-8px_rgba(255,30,30,.6)] transition hover:bg-ember"
              >
                إتمام الطلب <ArrowLeft size={18} />
              </Link>
              <Link to="/shop" className="mt-3 flex items-center justify-center gap-2 rounded-2xl border border-line py-3 text-sm font-extrabold text-mist transition hover:border-white/30 hover:text-cream">
                متابعة التسوق
              </Link>

              <div className="mt-5 flex items-center justify-center gap-2 text-[11px] font-bold text-mist">
                <ShieldCheck size={14} className="text-emerald-400" /> دفع آمن ومشفر 100%
              </div>
            </div>
          </aside>
        </div>
      )}
    </div>
  );
}
