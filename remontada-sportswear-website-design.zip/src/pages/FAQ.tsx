import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ChevronDown, MessageCircle, Phone } from "lucide-react";
import { SectionHead } from "../components/Reveal";
import { Reveal } from "../components/Reveal";

const FAQS = [
  { q: "كيف أشتري المنتج؟", a: "اضغط «تسوق الآن» أو استعرض المتجر واختر المنتج الذي يعجبك. اضغط «أضف إلى السلة»، ثم «إتمام الطلب» — ستصل إلى صفحة الدفع بعد انتهاء السلة." },
  { q: "ما هو زمن الشحن؟", a: "الشحن خلال 24-48 ساعة في المدن الرئيسية (الرياض، جدة، الدمام، مكة، المدينة). الشحن المجاني متاح للطلبات فوق 300 ر.س." },
  { q: "هل المنتجات أصلية؟", a: "نعم 100% — كل منتج يحمل ضماناً أصليّاً ومدة سنتين. نفحص كل منتج قبل شحنه ونرفق معه ختم أصلية العلامة التجارية." },
  { q: "كيف أسترجع أو أستبدل منتجاً؟", a: "يمكن استرداد أي سلعة خلال 14 يوماً بشرط حالتها الأصلية. اضغط «إرجاع المنتج» في صفحة المنتج أو تواصل معنا عبر WhatsApp، وسيتواصل معك فريقنا خلال 24 ساعة." },
  { q: "ما المقاسات المتوفرة؟", a: "نحصل على مجموعة واسعة: S إلى XXL للملابس، 36-44 للأحذية، وإضافة إلى ذلك جميع تصنيفات معدات الجيم والرياضي." },
  { q: "هل يمكنني تغيير موعد الشحن؟", a: "نعم — تواصل معنا قبل مرور 24 ساعة من الشحن، وسيقوم فريقنا بتأجيل الطلب ليوم آخر إن أمكن." },
  { q: "ما طريقة الدفع المقبولة؟", a: "نقبل بطاقات فيزا وماستركارد ومدّه، والمحافظ الإلكترونية مثل Apple Pay وSTC Pay وغيرها، بالإضافة إلى الدفع عند الاستلام." },
  { q: "كيف أطلب كوبوناً جديداً؟", a: "اشترك في النشرة البريدية في صفحة الرئيسية واحصل على خصم 30% من أول طلب. الكوبون REMONTADA30 نشط دائماً." },
];

export default function FAQ() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <div className="mx-auto max-w-4xl px-4 py-16 md:px-8 md:py-24">
      <Reveal>
        <SectionHead eyebrow="الأسئلة الشائعة" title={<>إجابات <span className="text-fiery">واضحة</span> قبل كل شيء</>} sub="لديك سؤال؟ خذ دقائق منك ونبني لك الجواب." />
      </Reveal>

      <div className="mt-12 space-y-3">
        {FAQS.map((f, i) => (
          <Reveal key={i} delay={Math.min(i * 0.05, 0.3)}>
            <div className={`overflow-hidden rounded-2xl border transition-colors duration-300 ${open === i ? "border-fiery/50 bg-smoke" : "border-line bg-coal hover:border-white/20"}`}>
              <button onClick={() => setOpen(open === i ? null : i)} className="flex w-full items-center justify-between gap-4 p-5 text-start">
                <span className="text-base font-extrabold text-cream">{f.q}</span>
                <span className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-full border transition-all duration-300 ${open === i ? "rotate-180 border-fiery bg-fiery text-white" : "border-line text-mist"}`}>
                  <ChevronDown size={17} />
                </span>
              </button>
              <AnimatePresence initial={false}>
                {open === i && (
                  <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.32, ease: [0.22, 1, 0.36, 1] }}>
                    <p className="px-5 pb-5 text-sm leading-8 text-mist">{f.a}</p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </Reveal>
        ))}
      </div>

      <Reveal className="mt-10">
        <div className="flex flex-col items-center justify-between gap-5 rounded-3xl border border-line bg-gradient-to-l from-smoke to-coal p-7 md:flex-row">
          <div>
            <h3 className="text-lg font-black text-white">لم تجد إجابة؟</h3>
            <p className="mt-1 text-sm text-mist">نحن هنا دائماً — تواصل معنا مباشرة.</p>
          </div>
          <div className="flex gap-3">
            <a href="https://wa.me/966500000000" target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-full bg-[#25D366] px-6 py-3 text-sm font-extrabold text-black transition hover:brightness-110">
              <MessageCircle size={17} /> واتساب
            </a>
            <a href="tel:+966500000000" className="inline-flex items-center gap-2 rounded-full border border-line px-6 py-3 text-sm font-extrabold text-cream transition hover:border-white/40">
              <Phone size={16} /> اتصال
            </a>
          </div>
        </div>
      </Reveal>
    </div>
  );
}
