import { useState } from "react";
import { Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowLeft, Clock, Flame, TrendingUp } from "lucide-react";
import { SectionHead, Reveal } from "../components/Reveal";

type Post = {
  id: string;
  title: string;
  category: string;
  read: string;
  img: string;
  excerpt: string;
  body: string[];
};

const POSTS: Post[] = [
  {
    id: "b1",
    title: "كيف تختار حذاء الجري الصحيح؟",
    category: "أحذية",
    read: "6 دقائق",
    img: "https://images.pexels.com/photos/30159784/pexels-photo-30159784.jpeg?auto=compress&cs=tinysrgb&w=1200&q=75",
    excerpt: "لا تختار الحذاء قبل صياغة خطتك — دليل كامل لتوازن التوزيع والضغط.",
    body: [
      "اختيار حذاء الجري ليس مسألة شكل — إنما قرار يتعلق بطريقة ملامستك للأرض. أول خطوة: حدّد نوع توزيع وزنك (Neutral / Pronation / Supination) عبر تحليل بسيط في متجر مختص.",
      "تذكر قاعدة مهمة: استبدل الحذاء كل 600 إلى 800 كيلومتر، وحاول حذاءاً جيداً بتوزيع مريح ودعم متوسط.",
      "أخيراً: جرّب حذاءك 300 كيلومتر قبل الاعتماد — السرّ هو تجربة الجري على الطريق بمبناه الحقيقي.",
    ],
  },
  {
    id: "b2",
    title: "التدريب للمبتدئين: 7 أيام كاملة",
    category: "تدريب",
    read: "8 دقائق",
    img: "https://images.pexels.com/photos/11433027/pexels-photo-11433027.jpeg?auto=compress&cs=tinysrgb&w=1200&q=75",
    excerpt: "خطة حقيقية لتبدأ التدريب دون أخطاء شائعة — ومدة كل تمرين مع فائدة أساسية.",
    body: [
      "يبدأ الأسلوب يوم الأحد: 30 دقيقة مشي سريع — اختر سطراً مستوياً أو مرتفعاً خفيف.",
      "الثلاثاء: تمارين القوة بنسبة تتراوح بين 30 و40% من قدراتك — مجموعة واحدة وحدّتان من 10 إلى 12 تكراراً لكل تمرين.",
      "الخميس: ركوب الدراجة أو الجري بنسبة 60 إلى 70% من الحد الأقصى — 30 دقيقة فقط.",
      "يوم السبت هو جلسة تحفيزية خفيفة دون ضغط — 15 دقيقة سير خارج المسار لتصل إلى الهدف.",
    ],
  },
  {
    id: "b3",
    title: "آخر أخبار كرة القدم 2026",
    category: "أخبار",
    read: "4 دقائق",
    img: "https://images.pexels.com/photos/39660176/pexels-photo-39660176.jpeg?auto=compress&cs=tinysrgb&w=1200&q=75",
    excerpt: "أهم الأخبار والأحداث في عالم كرة القدم هذا الموسم — ركّز على النقاط الحقيقية فقط.",
    body: [
      "يستمر الاستثمار في تنمية المواهب الشابة في كل عقدة — كل نادٍ يركّز على تطوير اللاعبين الشبان بدل التعاقد مع الكبار فقط.",
      "وتبدأ ورش وطنية في معالجة إدارة الطاقة — من التغذية إلى التعبئة البدنية.",
      "وثّق الأمر: الموسم قادراً على قلب قواعد اللعبة.",
    ],
  },
  {
    id: "b4",
    title: "الركوب خارج الملعب: نصائح المغامرين",
    category: "خارجية",
    read: "5 دقائق",
    img: "https://images.pexels.com/photos/33874843/pexels-photo-33874843.jpeg?auto=compress&cs=tinysrgb&w=1200&q=75",
    excerpt: "هل ترغب في المحاولة؟ خمسة أمور لا تتخطّى. ولا تتعلم الطريق دون تدريب.",
    body: [
      "الملابس المناسبة ليست رفاهية — بل ركيزة. احصل على خامة سريعة الجفاف وتهوية ممتازة.",
      "خطط مسارك زمنياً مسبقاً!",
      "ولا تنطلق دون رفيق: المغامرة ممتعة وخطيرة معاً.",
    ],
  },
  {
    id: "b5",
    title: "التقنية في الرقص: كاميراريا في التسجيل",
    category: "تقنية",
    read: "7 دقائق",
    img: "https://images.pexels.com/photos/36539818/pexels-photo-36539818.jpeg?auto=compress&cs=tinysrgb&w=1200&q=75",
    excerpt: "كيف تجعل تدريبك أكثر دقة من خلال التكنولوجيا.",
    body: [
      "المقاييس نفسها تتبع النبض والجري والسرعة المتوسطة — كلها متوفرة في هاتفك فقط.",
      "يجب تتبّع متوسط الأداء على مدى أسابيع وليس أيام لتفهم التقدم.",
      "وأسرار السباق هي الاستمرار، والتقدم بتعلّم صغير في كل جلسة تدريب.",
    ],
  },
  {
    id: "b6",
    title: "الجيم الذكي: جهاز تمرين للبيت",
    category: "جيم",
    read: "5 دقائق",
    img: "https://images.pexels.com/photos/10360933/pexels-photo-10360933.jpeg?auto=compress&cs=tinysrgb&w=1200&q=75",
    excerpt: "كيف تجهز ورشتك في المنزل بمكوّنات واقعية.",
    body: [
      "أربع أدوات أساسية: رافعة البنش، كيتل واحد بوزن مناسب، حبلان للمقاومة، ورفرف التدريب.",
      "تجهيز الباقي يكلف أقل مما يعتقد الكثيرون — الأساس هو النظام المنتظم وليس التمرين المستعجل.",
    ],
  },
];

const CAT_COLORS: Record<string, string> = {
  أحذية: "text-neo border-neo/40",
  تدريب: "text-fiery border-fiery/40",
  أخبار: "text-gold border-gold/40",
  خارجية: "text-emerald-400 border-emerald-400/40",
  تقنية: "text-purple-400 border-purple-400/40",
  جيم: "text-orange-400 border-orange-400/40",
};

export default function Blog() {
  const [active, setActive] = useState<Post | null>(null);

  return (
    <div className="mx-auto max-w-[1400px] px-4 py-16 md:px-8 md:py-24">
      <AnimatePresence mode="wait">
        {active ? (
          <motion.article
            key={active.id}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -30 }}
            transition={{ duration: 0.4 }}
          >
            <button onClick={() => setActive(null)} className="inline-flex items-center gap-2 text-xs font-bold text-mist transition hover:text-cream">
              <ArrowLeft size={15} className="rotate-180" /> العودة إلى المدونة
            </button>
            <img src={active.img} alt={active.title} className="mt-6 aspect-[16/8] w-full rounded-3xl border border-line object-cover" />
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <span className={`rounded-full border px-3 py-1 text-[11px] font-extrabold ${CAT_COLORS[active.category] ?? "border-line text-mist"}`}>
                {active.category}
              </span>
              <span className="flex items-center gap-1.5 text-[11px] font-bold text-mist">
                <Clock size={13} /> {active.read} قراءة
              </span>
            </div>
            <h1 className="mt-4 max-w-3xl text-3xl font-black leading-[1.3] text-white md:text-5xl md:leading-[1.2]">{active.title}</h1>
            <div className="mt-8 max-w-3xl space-y-5">
              {active.body.map((p, i) => (
                <p key={i} className="text-base leading-9 text-mist">{p}</p>
              ))}
            </div>
            <div className="mt-10 flex flex-wrap items-center gap-4 rounded-2xl border border-line bg-smoke p-6">
              <Flame size={20} className="text-fiery" />
              <p className="flex-1 text-sm text-cream">هل أعجبك هذا المقال؟ استكشف مجموعاتنا الجديدة وابدأ رحلتك.</p>
              <Link to="/shop" className="rounded-full bg-fiery px-6 py-3 text-sm font-extrabold text-white transition hover:bg-ember">
                تسوّق الآن
              </Link>
            </div>
          </motion.article>
        ) : (
          <motion.div key="list" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} transition={{ duration: 0.4 }}>
            <Reveal>
              <SectionHead eyebrow="المدونة" title={<>قصص <span className="text-fiery">تدريب</span>، خبرة واختيار</>} sub="مقالات عملية لمساعدتك على الدفع الأداء بعزم." />
            </Reveal>
            <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {POSTS.map((p, i) => (
                <Reveal key={p.id} delay={Math.min(i * 0.07, 0.35)}>
                  <button onClick={() => setActive(p)} className="group h-full w-full text-start">
                    <div className="relative h-52 overflow-hidden rounded-2xl border border-line">
                      <img src={p.img} alt={p.title} loading="lazy" className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110" />
                      <div className="absolute inset-0 bg-gradient-to-t from-ink/80 via-transparent to-transparent" />
                      <span className={`absolute top-3 start-3 rounded-full border bg-black/50 px-3 py-1 text-[10px] font-extrabold backdrop-blur ${CAT_COLORS[p.category] ?? "text-mist border-line"}`}>
                        {p.category}
                      </span>
                    </div>
                    <h3 className="mt-4 text-lg font-black leading-7 text-cream transition group-hover:text-white">{p.title}</h3>
                    <p className="mt-2 line-clamp-2 text-sm leading-7 text-mist">{p.excerpt}</p>
                    <span className="mt-3 inline-flex items-center gap-1.5 text-[11px] font-bold text-mist">
                      <Clock size={12} /> {p.read} قراءة
                    </span>
                  </button>
                </Reveal>
              ))}
            </div>

            <Reveal className="mt-16">
              <div className="flex flex-col items-center justify-between gap-5 rounded-3xl border border-line bg-gradient-to-l from-fiery/12 via-coal to-smoke p-8 md:flex-row">
                <div className="flex items-center gap-4">
                  <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gold/15 text-gold"><TrendingUp size={24} /></span>
                  <div>
                    <h3 className="text-lg font-black text-white">اشترك في نشرة الأخبار</h3>
                    <p className="mt-1 text-sm text-mist">نصائح أسبوعية للتدريب والأداء — لا إزعاج.</p>
                  </div>
                </div>
                <Link to="/" className="group inline-flex items-center gap-2 rounded-full bg-cream px-7 py-3.5 text-sm font-extrabold text-ink transition hover:bg-white">
                  اشترك الآن <ArrowLeft size={16} className="transition-transform group-hover:-translate-x-1" />
                </Link>
              </div>
            </Reveal>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
