import { useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import {
  Check,
  ChevronLeft,
  Eye,
  EyeOff,
  LogOut,
  Package,
  ShieldCheck,
  ShoppingBag,
  Star,
} from "lucide-react";
import { useStore } from "../context/StoreContext";
import { getProduct } from "../data/products";
import { SectionHead, Reveal } from "../components/Reveal";
import { ProductCard } from "../components/ProductCard";

export default function Account() {
  const { user, login, logout, orders, wishlist } = useStore();
  const [tab, setTab] = useState<"login" | "signup">("login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [pw, setPw] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [err, setErr] = useState("");

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (tab === "signup" && !name.trim()) return setErr("يرجى إدخال الاسم الكامل.");
    if (!email.includes("@")) return setErr("يرجى إدخال بريد إلكتروني صالح.");
    if (pw.length < 6) return setErr("كلمة المرور يجب أن تكون 6 أحرف على الأقل.");
    setErr("");
    login(tab === "signup" && name ? name.trim() : email.split("@")[0], email.trim());
  };

  if (!user) {
    return (
      <div className="mx-auto max-w-md px-4 py-16 md:py-24">
        <SectionHead eyebrow="حساب المستخدم" title={<>{tab === "login" ? "سجّل دخولك" : "أنشئ حساباً"}</>} sub="أهلاً بك مجدداً — امتلك طلباتك ومفضّلاتك." />
        <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} className="mt-10 rounded-3xl border border-line bg-coal p-6 md:p-7">
          <div className="flex rounded-xl border border-line bg-smoke p-1">
            {(["login", "signup"] as const).map((t) => (
              <button
                key={t}
                onClick={() => { setTab(t); setErr(""); }}
                className={`flex-1 rounded-lg py-2.5 text-sm font-extrabold transition ${tab === t ? "bg-fiery text-white" : "text-mist hover:text-cream"}`}
              >
                {t === "login" ? "تسجيل الدخول" : "إنشاء حساب"}
              </button>
            ))}
          </div>

          <form onSubmit={submit} className="mt-6 space-y-4">
            {tab === "signup" && (
              <div>
                <label className="field-label">الاسم الكامل</label>
                <input value={name} onChange={(e) => setName(e.target.value)} className="field" placeholder="مثال: عبدالله السالم" />
              </div>
            )}
            <div>
              <label className="field-label">البريد الإلكتروني</label>
              <input value={email} onChange={(e) => setEmail(e.target.value)} className="field" placeholder="you@email.com" dir="ltr" />
            </div>
            <div>
              <label className="field-label">كلمة المرور</label>
              <div className="relative">
                <input
                  type={showPw ? "text" : "password"}
                  value={pw}
                  onChange={(e) => setPw(e.target.value)}
                  className="field pe-12"
                  placeholder="••••••••"
                  dir="ltr"
                />
                <button type="button" onClick={() => setShowPw(!showPw)} className="absolute left-3 top-1/2 -translate-y-1/2 text-mist transition hover:text-cream" aria-label="إظهار/إخفاء">
                  {showPw ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>
            {err && <p className="text-xs font-bold text-fiery">{err}</p>}
            <button type="submit" className="w-full rounded-2xl bg-fiery py-4 font-extrabold text-white transition hover:bg-ember">
              {tab === "login" ? "دخول إلى حسابي" : "إنشاء حسابي"}
            </button>
          </form>
          <p className="mt-5 text-center text-[11px] leading-6 text-mist">
            بإكمال عملية التسجيل أنت توافق على سياسة الخصوصية علمائن.
          </p>
        </motion.div>

        <p className="mt-6 text-center">
          <Link to="/shop" className="inline-flex items-center gap-1.5 text-xs font-extrabold text-neo transition hover:text-white">
            متابعة التسوق دون تسجيل <ChevronLeft size={14} />
          </Link>
        </p>
      </div>
    );
  }

  const wishedProducts = wishlist.map((id) => getProduct(id)).filter((p): p is NonNullable<typeof p> => !!p);

  return (
    <div className="mx-auto max-w-[1100px] px-4 py-16 md:px-8 md:py-24">
      <Reveal>
        <div className="flex flex-wrap items-center justify-between gap-4 rounded-3xl border border-line bg-gradient-to-l from-fiery/12 via-coal to-smoke p-6 md:p-8">
          <div className="flex items-center gap-4">
            <span className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-ember to-fiery text-2xl font-black text-white shadow-lg shadow-fiery/25">
              {user.name[0]}
            </span>
            <div>
              <p className="text-[11px] font-extrabold tracking-wide text-mist">أهلاً بعودتك</p>
              <h1 className="text-2xl font-black text-white">{user.name}</h1>
              <p className="mt-0.5 text-xs font-bold text-mist">{user.email}</p>
            </div>
          </div>
          <button onClick={logout} className="inline-flex items-center gap-2 rounded-xl border border-line px-5 py-3 text-sm font-extrabold text-mist transition hover:border-red-500/50 hover:text-red-400">
            <LogOut size={16} /> تسجيل الخروج
          </button>
        </div>
      </Reveal>

      <div className="mt-8 flex flex-wrap gap-3">
        {[
          { icon: Package, label: "طلباتي", value: orders.length },
          { icon: Star, label: "المفضّلة", value: wishedProducts.length },
          { icon: ShieldCheck, label: "حالة الضمان", value: "نشط" },
        ].map((c) => (
          <div key={c.label} className="flex items-center gap-3 rounded-2xl border border-line bg-coal px-5 py-4">
            <c.icon size={20} className="text-fiery" />
            <div>
              <p className="text-lg font-black text-white">{c.value}</p>
              <p className="text-[11px] font-bold text-mist">{c.label}</p>
            </div>
          </div>
        ))}
      </div>

      {/* orders */}
      <section className="mt-12">
        <h2 className="text-xl font-black text-white">طلباتي</h2>
        <div className="mt-5 space-y-3">
          {orders.map((o) => {
            const step = o.status === "تم التوصيل" ? 3 : o.status === "تم الشحن" ? 2 : 1;
            return (
              <div key={o.id} className="rounded-2xl border border-line bg-coal p-5">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-white/5"><ShoppingBag size={19} className="text-gold" /></span>
                    <div>
                      <p className="font-display font-black text-white" dir="ltr">{o.id}</p>
                      <p className="text-[11px] font-bold text-mist">{o.date} • {o.items} {o.items > 1 ? "منتجات" : "منتج"}</p>
                    </div>
                  </div>
                  <span className={`rounded-full px-3.5 py-1.5 text-[11px] font-extrabold ${
                    o.status === "تم التوصيل" ? "bg-emerald-500/15 text-emerald-400" : o.status === "تم الشحن" ? "bg-neo/15 text-neo" : "bg-gold/15 text-gold"
                  }`}>
                    {o.status}
                  </span>
                  <p className="font-display text-xl font-black text-white">{o.total.toLocaleString("en-US")} <span className="text-xs text-mist">ر.س</span></p>
                </div>
                <div className="mt-4 flex items-center gap-2">
                  {["قيد التجهيز", "تم الشحن", "تم التوصيل"].map((s, i) => (
                    <div key={s} className="flex flex-1 flex-col items-center gap-1.5">
                      <div className={`h-1.5 w-full rounded-full transition-all duration-700 ${i + 1 <= step ? "bg-fiery" : "bg-line"}`} />
                      <span className={`text-[10px] font-bold ${i + 1 <= step ? "text-cream" : "text-mist/50"}`}>{s}</span>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* wishlist */}
      <section className="mt-12">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-black text-white">مفضّلاتي ({wishedProducts.length})</h2>
          <Link to="/shop" className="text-xs font-extrabold text-neo transition hover:text-white">مواصلة التسوق</Link>
        </div>
        {wishedProducts.length === 0 ? (
          <div className="mt-5 rounded-3xl border border-dashed border-line p-10 text-center">
            <ShieldCheck size={30} className="mx-auto text-mist/40" />
            <p className="mt-4 text-sm font-bold text-mist">لا توجد مفضّلات بعد — اضغط قلب أي منتج لتتمكن من تخزينه هنا.</p>
            <Link to="/shop" className="mt-5 inline-block rounded-full bg-fiery px-6 py-3 text-xs font-extrabold text-white transition hover:bg-ember">
              تصفح المتجر
            </Link>
          </div>
        ) : (
          <div className="mt-5 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {wishedProducts.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        )}
      </section>

      <div className="mt-10 flex items-center gap-3 rounded-2xl border border-line bg-coal p-5">
        <Check size={18} className="shrink-0 text-emerald-400" />
        <p className="text-xs leading-6 text-mist">كل طلباتك محفوظة على حسابك — حوّل بين أجهزة متعددة من نفس الحساب.</p>
      </div>
    </div>
  );
}
