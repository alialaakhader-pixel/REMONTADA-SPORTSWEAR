import { Link } from "react-router-dom";
import { Heart, Plus } from "lucide-react";
import type { Product } from "../data/products";
import { useStore } from "../context/StoreContext";
import { Stars } from "./Reveal";

export function Badge({ product }: { product: Product }) {
  if (!product.badge) return null;
  if (product.badge === "new")
    return (
      <span className="rounded-md bg-neo/15 px-2.5 py-1 text-[11px] font-extrabold text-neo ring-1 ring-neo/40">
        جديد
      </span>
    );
  if (product.badge === "bestseller")
    return (
      <span className="rounded-md bg-gold/15 px-2.5 py-1 text-[11px] font-extrabold text-gold ring-1 ring-gold/40">
        الأكثر مبيعاً
      </span>
    );
  if (product.badge === "limited")
    return (
      <span className="rounded-md bg-white/10 px-2.5 py-1 text-[11px] font-extrabold text-cream ring-1 ring-white/30">
        محدود الكمية
      </span>
    );
  const pct = product.oldPrice ? Math.round((1 - product.price / product.oldPrice) * 100) : 30;
  return (
    <span className="rounded-md bg-fiery px-2.5 py-1 text-[11px] font-extrabold text-white shadow-lg shadow-fiery/30">
      خصم {pct}%
    </span>
  );
}

export function ProductCard({ product, compact = false }: { product: Product; compact?: boolean }) {
  const { addToCart, toggleWishlist, wishlist } = useStore();
  const wished = wishlist.includes(product.id);

  return (
    <div className="group relative">
      <Link to={`/product/${product.id}`} className="block">
        <div className="relative overflow-hidden rounded-2xl border border-line bg-smoke">
          <img
            src={product.image}
            alt={product.name}
            loading="lazy"
            className="aspect-[4/5] w-full object-cover transition-transform duration-700 ease-out group-hover:scale-110"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-ink/80 via-ink/10 to-transparent opacity-70 transition-opacity duration-500 group-hover:opacity-90" />
          {product.badge && <div className="absolute top-3 start-3">{<Badge product={product} />}</div>}
          <button
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              toggleWishlist(product.id);
            }}
            aria-label="أضف إلى المفضلة"
            className={`absolute top-3 end-3 flex h-9 w-9 items-center justify-center rounded-full backdrop-blur-md transition-all duration-300 active:scale-90 ${
              wished ? "bg-fiery text-white" : "bg-black/50 text-cream hover:bg-black/70"
            }`}
          >
            <Heart size={16} className={wished ? "fill-current" : ""} />
          </button>
          <div className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-2 p-4">
            <div>
              <h3 className="text-base font-extrabold text-white md:text-lg">{product.name}</h3>
              <div className="mt-1 flex items-center gap-2">
                <Stars rating={product.rating} size={11} />
                <span className="text-[11px] font-bold text-white/70">({product.reviewCount})</span>
              </div>
            </div>
          </div>
        </div>
      </Link>

      <div className="relative mt-3 rounded-xl border border-line bg-coal p-3 transition-colors duration-300 group-hover:border-fiery/40">
        <div className="flex items-end justify-between gap-2">
          <div>
            <div className="flex items-baseline gap-2">
              <span className="font-display text-xl font-black text-white">{product.price}</span>
              <span className="text-xs font-bold text-mist">ر.س</span>
              {product.oldPrice && (
                <span className="text-xs font-semibold text-mist/70 line-through">{product.oldPrice}</span>
              )}
            </div>
            <p className="mt-0.5 text-[11px] font-semibold text-mist">{product.category} • {product.brand}</p>
          </div>
          {!compact && (
            <button
              onClick={() => addToCart(product.id, product.sizes[0], product.colors[0].name, 1)}
              className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-fiery text-white shadow-lg shadow-fiery/25 transition-all duration-300 hover:bg-ember hover:shadow-fiery/40 active:scale-90"
              aria-label="أضف إلى السلة"
            >
              <Plus size={18} strokeWidth={2.6} />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
