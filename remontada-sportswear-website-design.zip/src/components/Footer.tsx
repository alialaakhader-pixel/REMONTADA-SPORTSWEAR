import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Check, Send } from "lucide-react";
import { Logo } from "./Logo";

export function SocialIcon({ name }: { name: "instagram" | "facebook" | "tiktok" | "x" }) {
  const cls = "h-[18px] w-[18px]";
  if (name === "instagram")
    return (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={cls}>
        <rect x="2.5" y="2.5" width="19" height="19" rx="5.5" />
        <circle cx="12" cy="12" r="4.4" />
        <circle cx="17.35" cy="6.65" r="1.05" fill="currentColor" stroke="none" />
      </svg>
    );
  if (name === "facebook")
    return (
      <svg viewBox="0 0 24 24" fill="currentColor" className={cls}>
        <path d="M14.5 8.9V7.1c0-.8.2-1.3 1.4-1.3h1.6V3.2C16.5 3.1 15.6 3 14.4 3 11.5 3 9.9 4.7 9.9 7.6v1.3H8v3.2h1.9v9h3.5v-9h2.4l.4-3.2h-2.8V8.9z" />
      </svg>
    );
  if (name === "tiktok")
    return (
      <svg viewBox="0 0 24 24" fill="currentColor" className={cls}>
        <path d="M14.5 3.2c.5 2.2 2 3.5 4.3 3.7v3c-1.6 0-3-.5-4.3-1.4v6.8c0 3.2-2.3 5.5-5.2 5.5-2.9 0-5.1-2.2-5.1-5.1 0-2.9 2.2-5 5-5.2v3.2c-.9-.1-1.9.5-1.9 1.9 0 1.1.8 1.9 1.9 1.9 1.2 0 1.9-.8 1.9-2.7V3.2h3.3z" />
      </svg>
    );
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={cls}>
      <path d="M17.7 3.4h2.7l-6 6.8 7.2 10.4h-5.4l-4.3-6.3-4.9 6.3H4.4l6.4-7.3-5.8-8.6h5.5l3.9 5.5 4-5.5h1.5z" />
    </svg>
  );
}

export function Footer() {
  const [email, setEmail] = useState("");
  const [done, setDone] = useState(false);
  const navigate = useNavigate();

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.includes("@")) return;
    setDone(true);
    setEmail("");
  };

  return (
    <footer className="relative overflow-hidden border-t border-line bg-coal">
      <div className="speed-lines pointer-events-none absolute inset-0 opacity-70" />
      <div className="pointer-events-none absolute -bottom-40 left-1/2 h-80 w-[42rem] -translate-x-1/2 rounded-full bg-fiery/10 blur-[120px]" />

      <div className="relative mx-auto max-w-[1400px] px-4 py-14 md:px-8 md:py-16">
        <div className="grid gap-10 lg:grid-cols-[1.4fr_1fr_1fr_1.2fr]">
          <div>
            <Logo />
            <p className="mt-5 max-w-sm text-sm leading-7 text-mist">
              REMONTADA — متجر رياضي فاخر لكل من يطمح. ملابس وأحذية وإكسسوارات لكل الرياضات بأجود خامة وتشكيل عربي قوي.
            </p>
            <div className="mt-5 flex items-center gap-2.5">
              {(["instagram", "facebook", "tiktok", "x"] as const).map((s) => (
                <button
                  key={s}
                  className="flex h-10 w-10 items-center justify-center rounded-full border border-line text-mist transition-all duration-300 hover:border-fiery hover:bg-fiery hover:text-white"
                  aria-label={s}
                >
                  <SocialIcon name={s} />
                </button>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-sm font-extrabold tracking-wide text-cream">روابط سريعة</h4>
            <ul className="mt-4 space-y-2.5 text-sm">
              {[
                ["الرئيسية", "/"],
                ["المتجر", "/shop"],
                ["المدونة", "/blog"],
                ["من نحن", "/about"],
                ["الأسئلة الشائعة", "/faq"],
              ].map(([label, to]) => (
                <li key={to}>
                  <Link to={to} className="text-mist transition hover:text-fiery">
                    {label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-extrabold tracking-wide text-cream">تصفح حسب الرياضة</h4>
            <ul className="mt-4 space-y-2.5 text-sm">
              {["جري", "كرة القدم", "جيم وتدريب", "كرة السلة", "تنس", "سباحة", "ركوب الدراجات"].map((s) => (
                <li key={s}>
                  <button
                    onClick={() => navigate(`/shop?q=${s}`)}
                    className="text-mist transition hover:text-fiery"
                  >
                    {s}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-extrabold tracking-wide text-cream">النشرة البريدية</h4>
            <p className="mt-4 text-xs leading-6 text-mist">
              اشترك في نشرتنا واحصل على آخر العروض وأخبار مجموعات REMONTADA.
            </p>
            {done ? (
              <div className="mt-4 flex items-center gap-2 rounded-xl border border-emerald-500/30 bg-emerald-500/10 px-4 py-3 text-sm font-bold text-emerald-400">
                <Check size={18} /> تم الاشتراك بنجاح! أهلاً بك.
              </div>
            ) : (
              <form onSubmit={submit} className="mt-4 flex gap-2">
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="بريدك الإلكتروني"
                  className="field h-12 py-0 text-xs md:text-sm"
                />
                <button
                  type="submit"
                  className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-fiery text-white transition hover:bg-ember"
                  aria-label="اشترك"
                >
                  <Send size={17} className="-scale-x-100" />
                </button>
              </form>
            )}
            <div className="mt-5 rounded-xl border border-gold/25 bg-gold/5 p-4">
              <p className="text-[11px] font-extrabold tracking-wide text-gold">دفع آمن 100%</p>
              <div className="mt-2 flex flex-wrap gap-1.5">
                {["VISA", "MC", "MADA", "Apple Pay", "STC Pay"].map((p) => (
                  <span key={p} className="rounded-md border border-white/10 bg-black/50 px-2 py-1 font-display text-[9px] font-extrabold tracking-wider text-cream/80">
                    {p}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-line pt-6 text-xs text-mist md:flex-row">
          <p>© 2026 REMONTADA SPORTSWEAR — جميع الحقوق محفوظة.</p>
          <div className="flex items-center gap-5">
            <Link to="/refund" className="transition hover:text-cream">سياسة الإرجاع والاستبدال</Link>
            <Link to="/faq" className="transition hover:text-cream">الأسئلة الشائعة</Link>
            <Link to="/contact" className="transition hover:text-cream">تواصل معنا</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
