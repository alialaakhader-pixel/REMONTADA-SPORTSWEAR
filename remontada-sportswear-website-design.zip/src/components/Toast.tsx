import { AnimatePresence, motion } from "framer-motion";
import { CircleCheck } from "lucide-react";
import { useStore } from "../context/StoreContext";

export function Toasts() {
  const { toasts } = useStore();
  return (
    <div className="pointer-events-none fixed bottom-4 start-4 z-[90] flex flex-col gap-2.5">
      <AnimatePresence>
        {toasts.map((t) => (
          <motion.div
            key={t.id}
            initial={{ opacity: 0, y: 24, scale: 0.92 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, x: -40, scale: 0.92 }}
            transition={{ type: "spring", stiffness: 380, damping: 28 }}
            className="pointer-events-auto flex w-[320px] max-w-[calc(100vw-2rem)] items-start gap-3 rounded-2xl border border-line bg-coal/95 p-4 shadow-2xl shadow-black/60 backdrop-blur-xl"
          >
            <CircleCheck size={22} className="mt-0.5 shrink-0 text-emerald-400" />
            <div>
              <p className="text-sm font-extrabold text-cream">{t.title}</p>
              {t.desc && <p className="mt-0.5 text-xs text-mist">{t.desc}</p>}
            </div>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
