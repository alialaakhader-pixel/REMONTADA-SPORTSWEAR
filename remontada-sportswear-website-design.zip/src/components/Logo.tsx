import { Link } from "react-router-dom";

export function Logo({ size = "md", className = "" }: { size?: "sm" | "md" | "lg"; className?: string }) {
  const h = size === "lg" ? "h-16 w-16" : size === "sm" ? "h-9 w-9" : "h-11 w-11";
  const text = size === "lg" ? "text-2xl" : size === "sm" ? "text-base" : "text-xl";
  return (
    <Link
      to="/"
      className={`group flex shrink-0 items-center gap-2.5 md:gap-3 ${className}`}
      aria-label="REMONTADA الرئيسية"
    >
      <span
        className={`relative ${h} shrink-0 overflow-hidden rounded-xl ring-line transition-transform duration-500 group-hover:scale-105`}
        style={{ background: "radial-gradient(circle at 50% 38%, rgba(58,180,255,.28), #05070f 72%)" }}
      >
        <img
          src="/images/ibex-emblem.png"
          alt="REMONTADA Emblem"
          className="absolute inset-0 h-full w-full object-cover object-[center_38%] mix-blend-screen"
        />
      </span>
      <span className="flex flex-col leading-none">
        <span
          dir="ltr"
          className={`font-display font-black italic tracking-tight text-cream transition-colors duration-300 group-hover:text-white ${text}`}
          style={{ textShadow: "0 0 22px rgba(255,30,30,.35)" }}
        >
          REM<span className="text-fiery">O</span>NTADA
        </span>
        <span className="mt-1 font-display text-[0.5em] font-bold tracking-[0.62em] text-neo/90" style={{ textShadow: "0 0 14px rgba(58,180,255,.6)" }}>
          SPORTSWEAR
        </span>
      </span>
    </Link>
  );
}
