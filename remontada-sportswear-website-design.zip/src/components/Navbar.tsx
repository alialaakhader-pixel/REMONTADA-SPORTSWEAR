import { useEffect, useMemo, useState } from "react";
import { Link, NavLink, useNavigate } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import {
  Menu,
  Search,
  ShoppingCart,
  User,
  X,
  Zap,
  TrendingUp,
} from "lucide-react";
import { Logo } from "./Logo";
import { useStore } from "../context/StoreContext";
import { PRODUCTS, SPORTS_META } from "../data/products";

const NAV = [
  { to: "/", label: "الرئيسية" },
  { to: "/shop", label: "المتجر" },
  { to: "/blog", label: "المدونة" },
  { to: "/about", label: "من نحن" },
  { to: "/faq", label: "الأسئلة الشائعة" },
  { to: "/contact", label: "تواصل معنا" },
];

export function Ticker() {
  const items = [
    "شحن مجاني للطلبات فوق 300 ر.س",
    "توصيل سريع خلال 24-48 ساعة",
    "خصم 30% على العروض المميزة",
    "ضمان أصلي 100% على جميع المنتجات",
    "ارتقِ إلى مستواك التالي",
  ];
  return (
    <div dir="ltr" className="relative z-[52] overflow-hidden border-b border-line bg-gradient-to-r from-fiery via-ember to-fiery">
      <div className="flex w-max animate-marquee">
        {[0, 1].map((copy) => (
          <div key={copy} className="flex shrink-0 items-center" aria-hidden={copy === 1}>
            {items.map((t, i) => (
              <span key={i} className="flex items-center gap-3 px-8 py-2 text-[11px] font-extrabold tracking-wide text-white whitespace-nowrap">
                <Zap size={12} className="text-white" />
                {t}
              </span>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}

export function SearchOverlay({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [q, setQ] = useState("");
  const navigate = useNavigate();
  const results = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return [];
    return PRODUCTS.filter(
      (p) =>
        p.name.toLowerCase().includes(s) ||
        p.brand.toLowerCase().includes(s) ||
        p.category.toLowerCase().includes(s) ||
        SPORTS_META[p.sport].ar.toLowerCase().includes(s)
    ).slice(0, 6);
  }, [q]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.25 }}
          className="fixed inset-0 z-[80] overflow-y-auto bg-ink/95 backdrop-blur-xl"
        >
          <div className="mx-auto max-w-3xl px-5 py-10 md:py-16">
            <button
              onClick={onClose}
              className="ms-auto flex h-11 w-11 items-center justify-center rounded-full border border-line text-mist transition hover:border-fiery hover:text-white"
              aria-label="إغلاق البحث"
            >
              <X size={20} />
            </button>
            <p className="mt-6 text-center text-[11px] font-extrabold tracking-[0.3em] text-fiery">البحث السريع</p>
            <h2 className="mt-2 text-center text-3xl font-black text-cream md:text-4xl">
              ماذا تريد أن <span className="text-fiery">ترتقي</span> إليه؟
            </h2>
            <div className="relative mt-7">
              <Search className="absolute top-1/2 right-5 -translate-y-1/2 text-mist" size={22} />
              <input
                autoFocus
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="ابحث عن حذاء، قميص، أكسسوار..."
                className="w-full rounded-2xl border border-line bg-smoke/70 py-5 pr-14 pl-5 text-lg font-bold text-cream outline-none transition placeholder:font-medium placeholder:text-mist/60 focus:border-fiery/60"
              />
            </div>
            <div className="mt-7 space-y-2">
              {results.length === 0 && q.trim().length > 0 && (
                <p className="rounded-2xl border border-line bg-coal p-6 text-center text-sm text-mist">
                  لا توجد نتائج لـ «{q}» — جرّب كلمة أوسع مثل «حذاء» أو «هودي»
                </p>
              )}
              {results.map((p) => (
                <button
                  key={p.id}
                  onClick={() => {
                    onClose();
                    navigate(`/product/${p.id}`);
                  }}
                  className="group flex w-full items-center gap-4 rounded-2xl border border-line bg-coal p-3 text-right transition hover:border-fiery/50 hover:bg-smoke"
                >
                  <img src={p.image} alt={p.name} className="h-16 w-16 rounded-xl object-cover" />
                  <div className="flex-1">
                    <p className="font-extrabold text-cream group-hover:text-white">{p.name}</p>
                    <p className="text-xs font-semibold text-mist">{p.category} • {p.brand}</p>
                  </div>
                  <div className="text-left">
                    <p className="font-display text-lg font-black text-white">{p.price} <span className="text-xs text-mist">ر.س</span></p>
                  </div>
                </button>
              ))}
              {!q.trim() && (
                <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                  {PRODUCTS.slice(0, 4).map((p) => (
                    <button
                      key={p.id}
                      onClick={() => {
                        onClose();
                        navigate(`/product/${p.id}`);
                      }}
                      className="flex items-center gap-2 rounded-xl border border-line bg-coal p-3 text-right transition hover:border-fiery/40"
                    >
                      <TrendingUp size={16} className="shrink-0 text-fiery" />
                      <span className="truncate text-xs font-bold text-cream">{p.name}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

export function Navbar() {
  const { count, wishlist, user } = useStore();
  const [searchOpen, setSearchOpen] = useState(false);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <>
      <SearchOverlay open={searchOpen} onClose={() => setSearchOpen(false)} />
      <header
        className={`sticky top-0 z-[60] transition-all duration-500 ${
          scrolled ? "glass shadow-[0_18px_50px_-20px_rgba(0,0,0,.8)]" : "bg-transparent"
        }`}
      >
        <div className="mx-auto flex h-[72px] max-w-[1400px] items-center justify-between gap-4 px-4 md:px-8">
          <Logo />

          <nav className="hidden items-center gap-1 lg:flex">
            {NAV.map((n) => (
              <NavLink
                key={n.to}
                to={n.to}
                className={({ isActive }) =>
                  `relative rounded-lg px-4 py-2 text-sm font-bold transition-colors duration-300 ${
                    isActive ? "text-white" : "text-mist hover:text-white"
                  }`
                }
              >
                {({ isActive }) => (
                  <>
                    {n.label}
                    {isActive && (
                      <motion.span
                        layoutId="nav-pill"
                        className="absolute inset-x-3 -bottom-1 h-0.5 rounded-full bg-fiery"
                        transition={{ type: "spring", stiffness: 380, damping: 30 }}
                      />
                    )}
                  </>
                )}
              </NavLink>
            ))}
          </nav>

          <div className="flex items-center gap-1.5 md:gap-2.5">
            <button
              onClick={() => setSearchOpen(true)}
              aria-label="بحث"
              className="flex h-11 w-11 items-center justify-center rounded-full text-mist transition hover:bg-white/5 hover:text-white"
            >
              <Search size={20} />
            </button>
            <NavLink
              to="/account"
              aria-label="حسابي والمفضلة"
              className="relative hidden h-11 w-11 items-center justify-center rounded-full text-mist transition hover:bg-white/5 hover:text-white sm:flex"
            >
              {user ? <User size={20} className="text-gold" /> : <User size={20} />}
              {wishlist.length > 0 && (
                <span className="absolute -top-0.5 -end-0.5 flex h-5 min-w-5 items-center justify-center rounded-full bg-gold px-1 text-[10px] font-black text-ink">
                  {wishlist.length}
                </span>
              )}
            </NavLink>
            <NavLink
              to="/cart"
              aria-label="السلة"
              className="relative flex h-11 w-11 items-center justify-center rounded-full text-mist transition hover:bg-white/5 hover:text-white"
            >
              <ShoppingCart size={20} />
              <AnimatePresence>
                {count > 0 && (
                  <motion.span
                    key={count}
                    initial={{ scale: 0.4, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 0.4, opacity: 0 }}
                    className="absolute -top-0.5 -end-0.5 flex h-5 min-w-5 items-center justify-center rounded-full bg-fiery px-1 text-[10px] font-black text-white"
                  >
                    {count}
                  </motion.span>
                )}
              </AnimatePresence>
            </NavLink>
            <Link
              to="/shop"
              className="hidden items-center gap-2 rounded-full bg-cream px-5 py-2.5 text-sm font-extrabold text-ink transition-all duration-300 hover:bg-white hover:shadow-[0_0_30px_rgba(255,255,255,.25)] md:flex"
            >
              تسوق الآن
            </Link>
            <button
              onClick={() => setDrawerOpen(true)}
              aria-label="القائمة"
              className="flex h-11 w-11 items-center justify-center rounded-full border border-line text-cream lg:hidden"
            >
              <Menu size={20} />
            </button>
          </div>
        </div>
      </header>

      <AnimatePresence>
        {drawerOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setDrawerOpen(false)}
              className="fixed inset-0 z-[70] bg-ink/70 backdrop-blur-sm"
            />
            <motion.aside
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", stiffness: 320, damping: 34 }}
              className="fixed top-0 right-0 z-[75] flex h-full w-[85%] max-w-sm flex-col bg-coal p-6"
            >
              <div className="flex items-center justify-between">
                <Logo size="sm" />
                <button
                  onClick={() => setDrawerOpen(false)}
                  className="flex h-10 w-10 items-center justify-center rounded-full border border-line text-mist"
                  aria-label="إغلاق"
                >
                  <X size={18} />
                </button>
              </div>
              <nav className="mt-8 flex flex-col gap-1">
                {NAV.map((n, i) => (
                  <motion.div
                    key={n.to}
                    initial={{ opacity: 0, x: 30 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.06 * i }}
                  >
                    <Link
                      to={n.to}
                      onClick={() => setDrawerOpen(false)}
                      className="block rounded-xl px-4 py-3 text-lg font-extrabold text-cream transition hover:bg-white/5"
                    >
                      {n.label}
                    </Link>
                  </motion.div>
                ))}
              </nav>
              <div className="mt-auto border-t border-line pt-5">
                <p className="text-xs font-bold text-mist">لديك <span className="text-fiery font-black">{count}</span> منتجات في السلة</p>
                <Link
                  to="/cart"
                  onClick={() => setDrawerOpen(false)}
                  className="mt-3 flex items-center justify-center gap-2 rounded-xl bg-fiery py-3 text-sm font-extrabold text-white transition hover:bg-ember"
                >
                  <ShoppingCart size={16} /> التوجّه إلى السلة
                </Link>
              </div>
            </motion.aside>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
