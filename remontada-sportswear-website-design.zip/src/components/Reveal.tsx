import { motion } from "framer-motion";
import type { ReactNode } from "react";

export function Reveal({
  children,
  delay = 0,
  y = 34,
  className = "",
}: {
  children: ReactNode;
  delay?: number;
  y?: number;
  className?: string;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.75, delay, ease: [0.22, 1, 0.36, 1] }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

export function Eyebrow({ children }: { children: React.ReactNode }) {
  return (
    <span className="inline-flex items-center gap-2 text-[11px] font-extrabold tracking-[0.2em] text-fiery">
      <span className="h-px w-7 bg-fiery" />
      {children}
    </span>
  );
}

export function SectionHead({
  eyebrow,
  title,
  sub,
  align = "center",
}: {
  eyebrow: string;
  title: React.ReactNode;
  sub?: string;
  align?: "center" | "start";
}) {
  return (
    <div className={align === "center" ? "mx-auto max-w-2xl text-center" : "max-w-2xl"}>
      <Eyebrow>{eyebrow}</Eyebrow>
      <h2 className="mt-4 text-3xl font-black leading-[1.25] text-cream md:text-[2.6rem] md:leading-[1.2]">
        {title}
      </h2>
      {sub && <p className="mt-4 text-sm leading-8 text-mist md:text-base">{sub}</p>}
    </div>
  );
}

const STARS = [1, 2, 3, 4, 5];
export function Stars({ rating, size = 13 }: { rating: number; size?: number }) {
  return (
    <span dir="ltr" className="inline-flex items-center gap-0.5">
      {STARS.map((i) => (
        <svg
          key={i}
          width={size}
          height={size}
          viewBox="0 0 24 24"
          className={
            i <= Math.round(rating) ? "fill-gold text-gold" : "fill-white/10 text-white/10"
          }
        >
          <path d="M12 2.5l2.95 5.98 6.6.96-4.78 4.66 1.13 6.58L12 17.6l-5.9 3.1 1.12-6.58-4.78-4.66 6.6-.96L12 2.5z" />
        </svg>
      ))}
    </span>
  );
}
