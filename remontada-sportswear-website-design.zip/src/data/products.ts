export type SportId =
  | "running"
  | "football"
  | "gym"
  | "basketball"
  | "tennis"
  | "swimming"
  | "cycling"
  | "trail";

export type Product = {
  id: string;
  name: string;
  tagline: string;
  sport: SportId;
  category: string;
  gender: "رجالي" | "نسائي" | "للجنسين";
  brand: string;
  price: number;
  oldPrice?: number;
  rating: number;
  reviewCount: number;
  sizes: string[];
  colors: { name: string; hex: string }[];
  image: string;
  badge?: "new" | "bestseller" | "sale" | "limited";
  desc: string;
  spec: string;
  stock: number;
};

const px = (id: string, w = 1000) =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&w=${w}&q=78`;

export const HERO_IMG =
  "https://images.pexels.com/photos/35898730/pexels-photo-35898730.jpeg?auto=compress&cs=tinysrgb&w=1920&q=75";

export const SPORTS_META: Record<SportId, { ar: string; img: string }> = {
  running: { ar: "جري", img: px("30159784", 800) },
  football: { ar: "كرة القدم", img: px("39660176", 800) },
  gym: { ar: "جيم وتدريب", img: px("9073247", 800) },
  basketball: { ar: "كرة السلة", img: px("13250606", 800) },
  tennis: { ar: "تنس", img: px("21855870", 800) },
  swimming: { ar: "سباحة", img: px("34676992", 800) },
  cycling: { ar: "ركوب الدراجات", img: px("36539818", 800) },
  trail: { ar: "رياضات خارجية", img: px("33874843", 800) },
};

export const BRANDS = ["REMONTADA", "STRIDE", "APEX", "VOLT"];

export const CITIES = [
  { name: "الرياض", fee: 0 },
  { name: "جدة", fee: 15 },
  { name: "الدمام", fee: 20 },
  { name: "مكة المكرمة", fee: 15 },
  { name: "المدينة المنورة", fee: 15 },
  { name: "الخبر", fee: 20 },
  { name: "أخرى", fee: 35 },
];

export const FREE_SHIPPING_THRESHOLD = 300;
export const TAX_RATE = 0.15;

export function shippingFee(cityName: string, subtotal: number): number {
  if (subtotal >= FREE_SHIPPING_THRESHOLD) return 0;
  return CITIES.find((c) => c.name === cityName)?.fee ?? 35;
}

export const PRODUCTS: Product[] = [
  {
    id: "p-run-001",
    name: "حذاء رامي برو",
    tagline: "قوة الجري بتصميم خفيف",
    sport: "running",
    category: "أحذية",
    gender: "رجالي",
    brand: "STRIDE",
    price: 649,
    rating: 4.9,
    reviewCount: 214,
    sizes: ["40", "41", "42", "43", "44"],
    colors: [
      { name: "أسود ناري", hex: "#17171d" },
      { name: "أحمر", hex: "#e6392b" },
    ],
    image: px("19845610", 1100),
    badge: "bestseller",
    desc: "حذاء جري خفيف الوزن بمنصة هوائية متكاملة وتعلية ماصة للصدمات، صُمم لمسافات طويلة دون تعب. غطاء شبكي سريع التهوية يحافظ على برودة القدم في أشد الجو الداخلي حرارة.",
    spec: "وزن 280غ • منصة Air-Foam • نعل EVA • ضمان سنتان",
    stock: 18,
  },
  {
    id: "p-run-002",
    name: "حذاء الظلال",
    tagline: "رتم سريع قبل الفجر",
    sport: "running",
    category: "أحذية",
    gender: "نسائي",
    brand: "STRIDE",
    price: 549,
    oldPrice: 699,
    rating: 4.7,
    reviewCount: 89,
    sizes: ["36", "37", "38", "39"],
    colors: [
      { name: "عاجي", hex: "#f4f2ec" },
      { name: "أسود", hex: "#17171d" },
    ],
    image: px("25492111", 1100),
    badge: "sale",
    desc: "حذاء جري نسائي بتصميم عصري ومتّقد اللون، مبطنة بارتفاع متوسط يعزز الاتزان ويمنح ثباتاً حقيقياً في كل خطوة.",
    spec: "وزن 240غ • بطانة لينة • نعل متين • مقاومة الماء",
    stock: 22,
  },
  {
    id: "p-street-001",
    name: "هودي دايفستن",
    tagline: "راحة حاضنة في عصر الصخب",
    sport: "gym",
    category: "ملابس",
    gender: "رجالي",
    brand: "REMONTADA",
    price: 299,
    rating: 4.8,
    reviewCount: 342,
    sizes: ["S", "M", "L", "XL"],
    colors: [
      { name: "أسود", hex: "#17171d" },
      { name: "رمادي", hex: "#5b5b66" },
      { name: "ناري", hex: "#e6392b" },
    ],
    image: px("20248584", 1100),
    badge: "bestseller",
    desc: "هودي رياضي بخامة ثقيلة ومقواة، جيب أمامي مبطّن وأكمام منفتحة للتنفس. تصميم كلاسيكي يمنح الحضور اللطيف ويعكس روح المتحدين.",
    spec: "خامة 350غ • خياطة مزدوجة • أكمام مشددة • كابو بدقة 3 نقاط",
    stock: 34,
  },
  {
    id: "p-football-001",
    name: "قميص الانتصار 2.0",
    tagline: "راية الانتصار الأولى",
    sport: "football",
    category: "ملابس",
    gender: "رجالي",
    brand: "REMONTADA",
    price: 349,
    oldPrice: 499,
    rating: 4.9,
    reviewCount: 512,
    sizes: ["S", "M", "L", "XL", "XXL"],
    colors: [
      { name: "أسود", hex: "#17171d" },
      { name: "أحمر ناري", hex: "#e6392b" },
    ],
    image: px("27565819", 1100),
    badge: "sale",
    desc: "قميص كرة قدم بخامة ماصّة للرطوبة وشبكة تهوية خلف الأكتاف. شعار مطرز بدقة عالية وشريط عاكس للإضاءة الليلية.",
    spec: "خامة 100٪ قطن قطعت نشافة • شبكة تهوية • شعار مطرز",
    stock: 41,
  },
  {
    id: "p-gym-001",
    name: "كيتل #16 كجم",
    tagline: "قوة في كل قفزة",
    sport: "gym",
    category: "معدات",
    gender: "للجنسين",
    brand: "APEX",
    price: 599,
    rating: 4.8,
    reviewCount: 127,
    sizes: ["16", "20", "24"],
    colors: [{ name: "أسود معدني", hex: "#23232b" }],
    image: px("10360933", 1100),
    badge: "new",
    desc: "كيتل معدني مصبوب بدقة إنتاج صناع مع إطار محكم ومقبض ممتد يكسر حدة اليدين. مصمم لرفع وتطوير قوة التحمل حتى 24 كجم.",
    spec: "حديد مصبوب • مقاسات 2/4/8/10/16/20/24كجم • خامة صدئة محمية",
    stock: 12,
  },
  {
    id: "p-tennis-001",
    name: "راكت التسريع",
    tagline: "دقة وسرعة تُرهق خصمك",
    sport: "tennis",
    category: "معدات",
    gender: "رجالي",
    brand: "VOLT",
    price: 899,
    rating: 4.9,
    reviewCount: 66,
    sizes: ["L3", "L4", "L5"],
    colors: [
      { name: "أسود/برتقالي", hex: "#1c1c22" },
      { name: "أسود/أحمر", hex: "#17171d" },
    ],
    image: px("13789945", 1100),
    badge: "limited",
    desc: "راكت تنس بأطر ألياف كربونية خفيفة الوزن وزاوية عمود مضبوطة. يعزز القوة والسرعة مع تحكم دقيق في كل ضربة.",
    spec: "ألياف كربون • وزن 310غ • عمود 27.5سم • إطار 98مم",
    stock: 9,
  },
  {
    id: "p-acc-001",
    name: "قبعة القمة",
    tagline: "غطاء يرتفع مع رؤوس الأبطال",
    sport: "trail",
    category: "إكسسوارات",
    gender: "للجنسين",
    brand: "STRIDE",
    price: 124,
    rating: 4.6,
    reviewCount: 88,
    sizes: ["Free"],
    colors: [
      { name: "أسود", hex: "#17171d" },
      { name: "رمادي", hex: "#5b5b66" },
    ],
    image: px("16073272", 1100),
    badge: "new",
    desc: "قبعة رياضية بفتح تهوية خلفية وحافة مرنة قابلة للتعديل. خامة مقاومة للماء تحمي رأسك في الزحمة الخارجية.",
    spec: "خامة ماصة للرطوبة • حافة قابلة للتعديل • خياطة معززة",
    stock: 45,
  },
  {
    id: "p-swim-001",
    name: "ملابس السباحة الرعد",
    tagline: "غطس أول في كل دورة",
    sport: "swimming",
    category: "ملابس",
    gender: "للجنسين",
    brand: "VOLT",
    price: 189,
    rating: 4.7,
    reviewCount: 143,
    sizes: ["S", "M", "L"],
    colors: [
      { name: "أزرق نيون", hex: "#3ab4ff" },
      { name: "أسود", hex: "#17171d" },
    ],
    image: px("56837", 1100),
    badge: "sale",
    desc: "ملابس سباحة بإرجاع إطلاق سريع ومقاومة عالية للكلور والمياه المالحة. صُممت للاستثمار قبل أي دورة.",
    spec: "خامة مطاط المداح • مقاوم كلور • تصميم احتراضي",
    stock: 28,
  },
  {
    id: "p-basket-001",
    name: "كرة سبورت 8",
    tagline: "إطلاق لا يتوقف",
    sport: "basketball",
    category: "معدات",
    gender: "للجنسين",
    brand: "REMONTADA",
    price: 169,
    oldPrice: 219,
    rating: 4.8,
    reviewCount: 196,
    sizes: ["8"],
    colors: [{ name: "عنبري", hex: "#c96a2e" }],
    image: px("8858493", 1100),
    badge: "sale",
    desc: "كرة سلة بخامة ناعمة مدروسة تجمع بين الوزن الخفيف والضغط المتوسط. مثالية للتدريب على الأسطح الداخلية والخارجية.",
    spec: "جلد طبيعي • ضغط 8 PSI • وزن 620غ",
    stock: 60,
  },
  {
    id: "p-gym-002",
    name: "قميص العضلة",
    tagline: "قتال ثابت في الحجرة",
    sport: "gym",
    category: "ملابس",
    gender: "رجالي",
    brand: "APEX",
    price: 179,
    rating: 4.7,
    reviewCount: 74,
    sizes: ["S", "M", "L", "XL"],
    colors: [
      { name: "أسود", hex: "#17171d" },
      { name: "ذهبي", hex: "#c9a96a" },
    ],
    image: px("4218662", 1100),
    badge: "bestseller",
    desc: "تيشيرت جيم بخامة شديدة التهوية ومقاومة للحرارة، يطابق أشد لحظات التدريب دون تراجع. مقوّس للحركة الكاملة.",
    spec: "خامة سريعة الجفاف • خياطة مزدوجة • قصّ رياضي محكم",
    stock: 26,
  },
  {
    id: "p-trail-001",
    name: "قميص التضاريس",
    tagline: "قطع الجبال دون استسلام",
    sport: "trail",
    category: "ملابس",
    gender: "رجالي",
    brand: "VOLT",
    price: 199,
    rating: 4.6,
    reviewCount: 58,
    sizes: ["S", "M", "L", "XL"],
    colors: [
      { name: "رمادي أخضر", hex: "#3c4440" },
      { name: "أسود", hex: "#17171d" },
    ],
    image: px("13100144", 1100),
    badge: "new",
    desc: "قميص خارجي قابل للتمدد بخامة رقيقة سريعة التجفيف، يوفر التدفئة في الليل والبريد في الصباح. مثالي لمسحو المضمار والجبال.",
    spec: "خامة رقيقة • مرابطة بزاوية سريعة التنفس • مضاعف العمق",
    stock: 19,
  },
  {
    id: "p-cycling-001",
    name: "بنطال الركوب",
    tagline: "انزلاق للأمام في كل منحنى",
    sport: "cycling",
    category: "ملابس",
    gender: "للجنسين",
    brand: "STRIDE",
    price: 249,
    oldPrice: 329,
    rating: 4.8,
    reviewCount: 96,
    sizes: ["M", "L", "XL"],
    colors: [
      { name: "أسود", hex: "#17171d" },
      { name: "ناري", hex: "#e6392b" },
    ],
    image: px("5735768", 1100),
    badge: "sale",
    desc: "بنطال ركوب بدعم مبطن للركبة خفيف الوزن. صُمم لكسر الزمن حتى لو كنت تصل المنزل خالي الصورة.",
    spec: "دعم داخلي مبطن • تهوية مبردة • وزن 180غ",
    stock: 15,
  },
];

export const CATEGORY_ORDER = ["أحذية", "ملابس", "إكسسوارات", "معدات"];
export const GENDER_ORDER = ["رجالي", "نسائي", "للجنسين"] as const;

export const getProduct = (id: string) => PRODUCTS.find((p) => p.id === id);
export const relatedProducts = (p: Product, n = 4) =>
  PRODUCTS.filter((x) => x.id !== p.id && x.sport === p.sport).concat(
    PRODUCTS.filter((x) => x.id !== p.id && x.sport !== p.sport)
  ).slice(0, n);

export const formatPrice = (n: number) => `${n.toLocaleString("ar-SA")} ر.س`;
